// Header Navigation Functionality
class HeaderNavigation {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mainNav = document.querySelector('.main-nav');
        this.navMenu = document.querySelector('.nav-menu');
        this.isMobileMenuOpen = false;
        
        this.init();
    }

    init() {
        // Add event listener for mobile menu button
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Add event listener for window resize to handle responsive behavior
        window.addEventListener('resize', () => this.handleResize());

        // Add event listeners for navigation links
        this.addNavLinkEventListeners();

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => this.handleClickOutside(e));

        // Handle keyboard navigation
        this.handleKeyboardNavigation();
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.mainNav.classList.add('mobile-active');
        this.mobileMenuBtn.classList.add('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'true');
        
        // Add event listener to close menu when clicking on links
        this.addMobileLinkEventListeners();
    }

    closeMobileMenu() {
        this.mainNav.classList.remove('mobile-active');
        this.mobileMenuBtn.classList.remove('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'false');
        this.isMobileMenuOpen = false;
        
        // Remove mobile link event listeners
        this.removeMobileLinkEventListeners();
    }

    handleResize() {
        // Close mobile menu and reset state when window is resized to desktop size
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    addNavLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Update active state
                this.setActiveLink(link);
                
                // Close mobile menu if open
                if (this.isMobileMenuOpen) {
                    this.closeMobileMenu();
                }
            });
        });
    }

    addMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        this.mobileLinkClickHandler = (e) => {
            // Small delay to allow the click to register before closing menu
            setTimeout(() => {
                this.closeMobileMenu();
            }, 100);
        };
        
        navLinks.forEach(link => {
            link.addEventListener('click', this.mobileLinkClickHandler);
        });
    }

    removeMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        if (this.mobileLinkClickHandler) {
            navLinks.forEach(link => {
                link.removeEventListener('click', this.mobileLinkClickHandler);
            });
        }
    }

    setActiveLink(clickedLink) {
        // Remove active class from all links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to clicked link
        clickedLink.classList.add('active');
    }

    handleClickOutside(e) {
        if (this.isMobileMenuOpen && 
            !this.mainNav.contains(e.target) && 
            !this.mobileMenuBtn.contains(e.target)) {
            this.closeMobileMenu();
        }
    }

    handleKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close mobile menu on Escape key
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
                this.mobileMenuBtn.focus();
            }
        });

        // Trap focus in mobile menu when open
        this.mainNav.addEventListener('keydown', (e) => {
            if (!this.isMobileMenuOpen) return;

            const focusableElements = this.mainNav.querySelectorAll('a[href], button');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }

    // Public method to update active page
    updateActivePage(pageName) {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(pageName)) {
                link.classList.add('active');
            }
        });
    }
}

// Initialize header navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HeaderNavigation();
});

// Export for use in other modules (if using modules)
// export default HeaderNavigation;


// Departments Page Header Interactivity
class DepartmentsHeader {
    constructor() {
        this.init();
    }
    
    init() {
        this.initializeFloatingSymbols();
        this.initializeStatsAnimation();
        this.initializeScrollIndicator();
        this.initializeParallaxEffect();
        this.initializeBreadcrumbInteractions();
    }
    
    // Floating symbols animation
    initializeFloatingSymbols() {
        const symbols = document.querySelectorAll('.floating-symbol');
        
        symbols.forEach((symbol, index) => {
            // Randomize initial positions and animations
            const randomX = Math.random() * 80 + 10;
            const randomY = Math.random() * 80 + 10;
            const randomDelay = Math.random() * 20;
            const randomDuration = Math.random() * 10 + 20;
            
            symbol.style.left = `${randomX}%`;
            symbol.style.top = `${randomY}%`;
            symbol.style.animationDuration = `${randomDuration}s`;
            symbol.style.animationDelay = `-${randomDelay}s`;
            
            // Add hover effect
            symbol.addEventListener('mouseenter', () => {
                this.enhanceSymbol(symbol);
            });
            
            symbol.addEventListener('mouseleave', () => {
                this.resetSymbol(symbol);
            });
        });
    }
    
    enhanceSymbol(symbol) {
        symbol.style.transform = 'scale(1.5)';
        symbol.style.opacity = '1';
        symbol.style.filter = 'drop-shadow(0 8px 16px rgba(0, 0, 0, 0.3))';
        symbol.style.zIndex = '100';
        symbol.style.transition = 'all 0.3s ease';
    }
    
    resetSymbol(symbol) {
        symbol.style.transform = '';
        symbol.style.opacity = '0.7';
        symbol.style.filter = 'drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2))';
        symbol.style.zIndex = '';
        symbol.style.transition = 'all 0.3s ease';
    }
    
    // Animated stats counter
    initializeStatsAnimation() {
        const stats = [
            { element: document.getElementById('departmentsCount'), target: 12, duration: 2000 },
            { element: document.getElementById('facultyCount'), target: 85, duration: 2500 },
            { element: document.getElementById('programsCount'), target: 50, duration: 3000 }
        ];
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    stats.forEach(stat => {
                        this.animateCounter(stat.element, stat.target, stat.duration);
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(document.querySelector('.departments-quick-stats'));
    }
    
    animateCounter(element, target, duration) {
        const start = 0;
        const increment = target / (duration / 16);
        let current = start;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                clearInterval(timer);
                current = target;
            }
            
            if (element.id === 'facultyCount' || element.id === 'programsCount') {
                element.textContent = `${Math.floor(current)}+`;
            } else {
                element.textContent = Math.floor(current);
            }
        }, 16);
    }
    
    // Scroll indicator functionality
    initializeScrollIndicator() {
        const scrollIndicator = document.querySelector('.scroll-indicator');
        
        scrollIndicator.addEventListener('click', () => {
            this.smoothScrollToDepartments();
        });
        
        // Hide scroll indicator when user starts scrolling
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                scrollIndicator.style.opacity = '0';
                scrollIndicator.style.pointerEvents = 'none';
            } else {
                scrollIndicator.style.opacity = '1';
                scrollIndicator.style.pointerEvents = 'auto';
            }
        });
    }
    
    smoothScrollToDepartments() {
        const departmentsSection = document.querySelector('.departments-overview-section') || 
                                 document.querySelector('main');
        
        if (departmentsSection) {
            departmentsSection.scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
    
    // Parallax background effect
    initializeParallaxEffect() {
        const header = document.querySelector('.departments-page-header');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            header.style.transform = `translateY(${rate}px)`;
        });
    }
    
    // Breadcrumb interactions
    initializeBreadcrumbInteractions() {
        const breadcrumbLinks = document.querySelectorAll('.breadcrumb-link');
        
        breadcrumbLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                
                // Add click animation
                link.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    link.style.transform = '';
                }, 150);
                
                // Simulate navigation (in real implementation, this would navigate)
                console.log(`Navigating to: ${href}`);
                // window.location.href = href;
            });
        });
    }
    
    // Handle page load animations
    handlePageLoad() {
        document.body.style.opacity = '0';
        
        setTimeout(() => {
            document.body.style.transition = 'opacity 0.8s ease';
            document.body.style.opacity = '1';
        }, 100);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const departmentsHeader = new DepartmentsHeader();
    departmentsHeader.handlePageLoad();
});

// Handle responsive behavior
window.addEventListener('resize', () => {
    // Re-initialize floating symbols on resize
    const symbols = document.querySelectorAll('.floating-symbol');
    symbols.forEach(symbol => {
        symbol.style.animation = 'none';
        setTimeout(() => {
            symbol.style.animation = '';
        }, 10);
    });
});

// Add keyboard navigation support
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        const scrollIndicator = document.querySelector('.scroll-indicator');
        if (scrollIndicator) {
            scrollIndicator.click();
        }
    }
});

// Performance optimization: Reduce animations when page is not visible
document.addEventListener('visibilitychange', () => {
    const symbols = document.querySelectorAll('.floating-symbol');
    
    if (document.hidden) {
        symbols.forEach(symbol => {
            symbol.style.animationPlayState = 'paused';
        });
    } else {
        symbols.forEach(symbol => {
            symbol.style.animationPlayState = 'running';
        });
    }
});

// Departments Overview Section Interactivity
class DepartmentsOverview {
    constructor() {
        this.init();
    }
    
    init() {
        this.initializeFeatureCards();
        this.initializeDisciplineItems();
        this.initializeCTAButtons();
        this.initializeScrollAnimations();
        this.initializeInteractiveElements();
    }
    
    // Feature cards interactions
    initializeFeatureCards() {
        const featureCards = document.querySelectorAll('.feature-card');
        
        featureCards.forEach(card => {
            // Click interaction
            card.addEventListener('click', () => {
                this.activateFeatureCard(card);
            });
            
            // Keyboard navigation
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.activateFeatureCard(card);
                }
            });
            
            // Hover effects with delay
            let hoverTimeout;
            card.addEventListener('mouseenter', () => {
                hoverTimeout = setTimeout(() => {
                    this.highlightRelatedDisciplines(card);
                }, 300);
            });
            
            card.addEventListener('mouseleave', () => {
                clearTimeout(hoverTimeout);
                this.resetDisciplineHighlights();
            });
        });
    }
    
    activateFeatureCard(card) {
        // Remove active state from all cards
        document.querySelectorAll('.feature-card').forEach(c => {
            c.classList.remove('card-active');
            c.style.zIndex = '1';
        });
        
        // Add active state to clicked card
        card.classList.add('card-active');
        card.style.zIndex = '10';
        
        // Animate the activation
        card.style.transform = 'translateY(-20px) scale(1.02)';
        
        // Show feature details (could be expanded with more content)
        this.showFeatureDetails(card);
    }
    
    showFeatureDetails(card) {
        const featureType = card.getAttribute('data-feature');
        console.log(`Showing details for: ${featureType}`);
        // In a real implementation, this could show a modal or expand the card
    }
    
    // Discipline items interactions
    initializeDisciplineItems() {
        const disciplineItems = document.querySelectorAll('.discipline-item');
        
        disciplineItems.forEach(item => {
            // Click to filter departments
            item.addEventListener('click', () => {
                this.filterByDiscipline(item);
            });
            
            // Enhanced hover effects
            item.addEventListener('mouseenter', () => {
                this.enhanceDisciplineHover(item);
            });
            
            item.addEventListener('mouseleave', () => {
                this.resetDisciplineHover(item);
            });
            
            // Touch device support
            item.addEventListener('touchstart', () => {
                this.enhanceDisciplineHover(item);
            });
            
            item.addEventListener('touchend', () => {
                setTimeout(() => {
                    this.resetDisciplineHover(item);
                }, 1000);
            });
        });
    }
    
    filterByDiscipline(item) {
        const discipline = item.getAttribute('data-discipline');
        
        // Visual feedback
        item.style.transform = 'scale(0.95)';
        setTimeout(() => {
            item.style.transform = '';
        }, 150);
        
        // Show loading state
        this.showLoadingState(discipline);
        
        // In real implementation, this would filter departments
        console.log(`Filtering by discipline: ${discipline}`);
    }
    
    showLoadingState(discipline) {
        const disciplineItems = document.querySelectorAll('.discipline-item');
        
        disciplineItems.forEach(item => {
            if (item.getAttribute('data-discipline') === discipline) {
                item.style.opacity = '0.7';
                item.style.pointerEvents = 'none';
                
                // Add loading animation
                const icon = item.querySelector('.discipline-icon');
                icon.style.animation = 'spin 1s linear infinite';
                
                setTimeout(() => {
                    item.style.opacity = '1';
                    item.style.pointerEvents = 'auto';
                    icon.style.animation = '';
                }, 1000);
            }
        });
    }
    
    enhanceDisciplineHover(item) {
        const discipline = item.getAttribute('data-discipline');
        const icon = item.querySelector('.discipline-icon');
        
        // Scale and color effect
        icon.style.transform = 'scale(1.4) rotate(10deg)';
        item.style.background = this.getDisciplineColor(discipline, 0.05);
        
        // Add pulse animation
        item.style.animation = 'pulseBorder 2s infinite';
    }
    
    resetDisciplineHover(item) {
        const icon = item.querySelector('.discipline-icon');
        
        icon.style.transform = '';
        item.style.background = '';
        item.style.animation = '';
    }
    
    getDisciplineColor(discipline, opacity = 1) {
        const colors = {
            'stem': `rgba(52, 152, 219, ${opacity})`,
            'humanities': `rgba(231, 76, 60, ${opacity})`,
            'arts': `rgba(155, 89, 182, ${opacity})`,
            'languages': `rgba(46, 204, 113, ${opacity})`,
            'business': `rgba(243, 156, 18, ${opacity})`,
            'health': `rgba(230, 126, 34, ${opacity})`
        };
        
        return colors[discipline] || `rgba(52, 152, 219, ${opacity})`;
    }
    
    highlightRelatedDisciplines(card) {
        const feature = card.getAttribute('data-feature');
        const relatedDisciplines = this.getRelatedDisciplines(feature);
        
        document.querySelectorAll('.discipline-item').forEach(item => {
            const discipline = item.getAttribute('data-discipline');
            if (relatedDisciplines.includes(discipline)) {
                item.style.transform = 'scale(1.1)';
                item.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.2)';
            }
        });
    }
    
    resetDisciplineHighlights() {
        document.querySelectorAll('.discipline-item').forEach(item => {
            item.style.transform = '';
            item.style.boxShadow = '';
        });
    }
    
    getRelatedDisciplines(feature) {
        const relations = {
            'curriculum': ['stem', 'humanities', 'arts', 'languages', 'business', 'health'],
            'faculty': ['stem', 'humanities'],
            'facilities': ['stem', 'arts', 'health'],
            'support': ['stem', 'languages', 'business']
        };
        
        return relations[feature] || [];
    }
    
    // CTA Buttons functionality
    initializeCTAButtons() {
        const exploreBtn = document.getElementById('exploreDepartmentsBtn');
        const programsBtn = document.getElementById('viewProgramsBtn');
        
        if (exploreBtn) {
            exploreBtn.addEventListener('click', () => {
                this.navigateToDepartments();
            });
        }
        
        if (programsBtn) {
            programsBtn.addEventListener('click', () => {
                this.navigateToPrograms();
            });
        }
    }
    
    navigateToDepartments() {
        // Add click animation
        const btn = document.getElementById('exploreDepartmentsBtn');
        btn.style.transform = 'scale(0.95)';
        
        setTimeout(() => {
            btn.style.transform = '';
        }, 150);
        
        // Navigate to departments section
        console.log('Navigating to departments...');
        // window.location.href = '#departments-list';
    }
    
    navigateToPrograms() {
        const btn = document.getElementById('viewProgramsBtn');
        btn.style.transform = 'scale(0.95)';
        
        setTimeout(() => {
            btn.style.transform = '';
        }, 150);
        
        console.log('Navigating to programs...');
        // window.location.href = 'programs.html';
    }
    
    // Scroll animations
    initializeScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateOnScroll(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe feature cards and discipline items
        document.querySelectorAll('.feature-card, .discipline-item').forEach(el => {
            observer.observe(el);
        });
    }
    
    animateOnScroll(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            element.style.transition = 'all 0.6s ease';
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Additional interactive elements
    initializeInteractiveElements() {
        // Add CSS for animations
        this.addAnimationStyles();
        
        // Initialize tooltips for mobile
        this.initializeMobileTooltips();
    }
    
    addAnimationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            @keyframes pulseBorder {
                0%, 100% { box-shadow: 0 5px 20px rgba(0, 0, 0, 0.06); }
                50% { box-shadow: 0 5px 30px rgba(52, 152, 219, 0.3); }
            }
            
            .feature-card.card-active {
                box-shadow: 0 25px 80px rgba(0, 0, 0, 0.2) !important;
            }
        `;
        document.head.appendChild(style);
    }
    
    initializeMobileTooltips() {
        // Enhanced tooltip behavior for touch devices
        if ('ontouchstart' in window) {
            document.querySelectorAll('.discipline-item').forEach(item => {
                item.addEventListener('touchstart', (e) => {
                    e.preventDefault();
                    const tooltip = item.querySelector('.discipline-tooltip');
                    tooltip.style.opacity = '1';
                    tooltip.style.visibility = 'visible';
                    
                    // Hide after delay
                    setTimeout(() => {
                        tooltip.style.opacity = '0';
                        tooltip.style.visibility = 'hidden';
                    }, 3000);
                });
            });
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const departmentsOverview = new DepartmentsOverview();
});

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DepartmentsOverview;
}


// Department Navigation & Filter System
class DepartmentFilterSystem {
    constructor() {
        this.currentFilters = {
            category: 'all',
            search: '',
            letter: 'all',
            view: 'grid'
        };
        
        this.departmentsData = this.generateSampleData();
        this.init();
    }
    
    init() {
        this.initializeSearch();
        this.initializeFilterTabs();
        this.initializeAlphabetNav();
        this.initializeViewToggle();
        this.initializeActiveFilters();
        this.initializeEventListeners();
        this.updateDepartmentCounts();
    }
    
    // Generate sample department data
    generateSampleData() {
        return [
            { id: 1, name: "Mathematics", category: "core", letter: "m", subjects: ["Algebra", "Calculus", "Statistics"] },
            { id: 2, name: "English Language", category: "core", letter: "e", subjects: ["Literature", "Composition", "Grammar"] },
            { id: 3, name: "Science", category: "core", letter: "s", subjects: ["Biology", "Chemistry", "Physics"] },
            { id: 4, name: "Social Studies", category: "core", letter: "s", subjects: ["History", "Geography", "Civics"] },
            { id: 5, name: "Physics", category: "stem", letter: "p", subjects: ["Mechanics", "Electromagnetism", "Quantum Physics"] },
            { id: 6, name: "Chemistry", category: "stem", letter: "c", subjects: ["Organic Chemistry", "Biochemistry", "Analytical Chemistry"] },
            { id: 7, name: "Computer Science", category: "stem", letter: "c", subjects: ["Programming", "Algorithms", "Data Structures"] },
            { id: 8, name: "History", category: "humanities", letter: "h", subjects: ["World History", "US History", "European History"] },
            { id: 9, name: "Art & Design", category: "humanities", letter: "a", subjects: ["Drawing", "Painting", "Digital Art"] },
            { id: 10, name: "Music", category: "humanities", letter: "m", subjects: ["Music Theory", "Orchestra", "Choir"] },
            { id: 11, name: "Spanish", category: "languages", letter: "s", subjects: ["Spanish I", "Spanish II", "Advanced Spanish"] },
            { id: 12, name: "French", category: "languages", letter: "f", subjects: ["French I", "French II", "French Literature"] },
            { id: 13, name: "Business Studies", category: "vocational", letter: "b", subjects: ["Accounting", "Marketing", "Management"] },
            { id: 14, name: "Technology Education", category: "vocational", letter: "t", subjects: ["Woodworking", "Electronics", "CAD Design"] }
        ];
    }
    
    // Search functionality
    initializeSearch() {
        const searchInput = document.getElementById('departmentSearch');
        const clearBtn = document.getElementById('searchClearBtn');
        const resultsCount = document.getElementById('searchResultsCount');
        
        // Search input handler with debouncing
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.currentFilters.search = e.target.value.trim().toLowerCase();
                this.updateClearButton();
                this.applyFilters();
            }, 300);
        });
        
        // Clear search
        clearBtn.addEventListener('click', () => {
            searchInput.value = '';
            this.currentFilters.search = '';
            this.updateClearButton();
            this.applyFilters();
            searchInput.focus();
        });
        
        // Enter key to search
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.applyFilters();
            }
        });
    }
    
    updateClearButton() {
        const clearBtn = document.getElementById('searchClearBtn');
        const searchInput = document.getElementById('departmentSearch');
        
        if (this.currentFilters.search) {
            clearBtn.classList.add('visible');
        } else {
            clearBtn.classList.remove('visible');
        }
    }
    
    // Filter tabs functionality
    initializeFilterTabs() {
        const filterTabs = document.querySelectorAll('.filter-tab');
        
        filterTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const filterValue = tab.getAttribute('data-filter');
                this.setActiveFilterTab(filterValue);
                this.currentFilters.category = filterValue;
                this.applyFilters();
            });
            
            // Keyboard navigation
            tab.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const filterValue = tab.getAttribute('data-filter');
                    this.setActiveFilterTab(filterValue);
                    this.currentFilters.category = filterValue;
                    this.applyFilters();
                }
            });
        });
    }
    
    setActiveFilterTab(filterValue) {
        // Update tab states
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.classList.remove('active');
            tab.setAttribute('aria-selected', 'false');
        });
        
        const activeTab = document.querySelector(`[data-filter="${filterValue}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
            activeTab.setAttribute('aria-selected', 'true');
        }
    }
    
    // Alphabet navigation
    initializeAlphabetNav() {
        const alphabetLetters = document.querySelectorAll('.alphabet-letter');
        
        alphabetLetters.forEach(letter => {
            letter.addEventListener('click', () => {
                const letterValue = letter.getAttribute('data-letter');
                this.setActiveAlphabetLetter(letterValue);
                this.currentFilters.letter = letterValue;
                this.applyFilters();
            });
        });
    }
    
    setActiveAlphabetLetter(letterValue) {
        document.querySelectorAll('.alphabet-letter').forEach(letter => {
            letter.classList.remove('active');
        });
        
        const activeLetter = document.querySelector(`[data-letter="${letterValue}"]`);
        if (activeLetter) {
            activeLetter.classList.add('active');
        }
    }
    
    // View toggle functionality
    initializeViewToggle() {
        const viewButtons = document.querySelectorAll('.view-toggle-btn');
        
        viewButtons.forEach(button => {
            button.addEventListener('click', () => {
                const viewType = button.getAttribute('data-view');
                this.setActiveView(viewType);
                this.currentFilters.view = viewType;
                this.updateViewLayout();
            });
        });
    }
    
    setActiveView(viewType) {
        document.querySelectorAll('.view-toggle-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeButton = document.querySelector(`[data-view="${viewType}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
        }
    }
    
    updateViewLayout() {
        // This would update the actual departments display layout
        console.log(`Switching to ${this.currentFilters.view} view`);
        // In real implementation, this would trigger layout changes in the departments grid/list
    }
    
    // Active filters management
    initializeActiveFilters() {
        const clearAllBtn = document.getElementById('clearAllFilters');
        const resetFiltersBtn = document.getElementById('resetFiltersBtn');
        
        clearAllBtn.addEventListener('click', () => {
            this.clearAllFilters();
        });
        
        resetFiltersBtn.addEventListener('click', () => {
            this.clearAllFilters();
        });
    }
    
    updateActiveFiltersDisplay() {
        const activeFiltersSection = document.getElementById('activeFilters');
        const activeFiltersList = document.getElementById('activeFiltersList');
        
        // Get active filters (excluding defaults)
        const activeFilters = [];
        
        if (this.currentFilters.category !== 'all') {
            activeFilters.push({
                type: 'category',
                value: this.currentFilters.category,
                label: this.getFilterLabel('category', this.currentFilters.category)
            });
        }
        
        if (this.currentFilters.letter !== 'all') {
            activeFilters.push({
                type: 'letter',
                value: this.currentFilters.letter,
                label: `Starts with ${this.currentFilters.letter.toUpperCase()}`
            });
        }
        
        if (this.currentFilters.search) {
            activeFilters.push({
                type: 'search',
                value: this.currentFilters.search,
                label: `Search: "${this.currentFilters.search}"`
            });
        }
        
        // Update display
        if (activeFilters.length > 0) {
            activeFiltersSection.classList.add('visible');
            
            activeFiltersList.innerHTML = activeFilters.map(filter => `
                <div class="active-filter-item" data-filter-type="${filter.type}" data-filter-value="${filter.value}">
                    <span>${filter.label}</span>
                    <button class="remove-filter-btn" aria-label="Remove ${filter.label} filter">×</button>
                </div>
            `).join('');
            
            // Add event listeners to remove buttons
            activeFiltersList.querySelectorAll('.remove-filter-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const filterItem = btn.closest('.active-filter-item');
                    const filterType = filterItem.getAttribute('data-filter-type');
                    const filterValue = filterItem.getAttribute('data-filter-value');
                    this.removeFilter(filterType, filterValue);
                });
            });
        } else {
            activeFiltersSection.classList.remove('visible');
        }
    }
    
    getFilterLabel(type, value) {
        const labels = {
            category: {
                'core': 'Core Subjects',
                'stem': 'STEM Fields',
                'humanities': 'Humanities & Arts',
                'languages': 'Languages',
                'vocational': 'Vocational Studies'
            }
        };
        
        return labels[type]?.[value] || value;
    }
    
    removeFilter(filterType, filterValue) {
        switch(filterType) {
            case 'category':
                this.currentFilters.category = 'all';
                this.setActiveFilterTab('all');
                break;
            case 'letter':
                this.currentFilters.letter = 'all';
                this.setActiveAlphabetLetter('all');
                break;
            case 'search':
                this.currentFilters.search = '';
                document.getElementById('departmentSearch').value = '';
                this.updateClearButton();
                break;
        }
        
        this.applyFilters();
    }
    
    clearAllFilters() {
        // Reset all filters to default
        this.currentFilters = {
            category: 'all',
            search: '',
            letter: 'all',
            view: this.currentFilters.view // Keep current view
        };
        
        // Update UI elements
        this.setActiveFilterTab('all');
        this.setActiveAlphabetLetter('all');
        document.getElementById('departmentSearch').value = '';
        this.updateClearButton();
        
        this.applyFilters();
    }
    
    // Main filter application
    applyFilters() {
        this.showLoadingState();
        
        // Simulate API call delay
        setTimeout(() => {
            const filteredDepartments = this.filterDepartments();
            this.updateResultsCount(filteredDepartments.length);
            this.updateActiveFiltersDisplay();
            this.hideLoadingState();
            
            if (filteredDepartments.length === 0) {
                this.showNoResultsState();
            } else {
                this.hideNoResultsState();
            }
            
            // In real implementation, this would update the departments display
            console.log('Filtered departments:', filteredDepartments);
            
        }, 500);
    }
    
    filterDepartments() {
        return this.departmentsData.filter(dept => {
            // Category filter
            if (this.currentFilters.category !== 'all' && dept.category !== this.currentFilters.category) {
                return false;
            }
            
            // Letter filter
            if (this.currentFilters.letter !== 'all' && dept.letter !== this.currentFilters.letter) {
                return false;
            }
            
            // Search filter
            if (this.currentFilters.search) {
                const searchTerm = this.currentFilters.search.toLowerCase();
                const matchesName = dept.name.toLowerCase().includes(searchTerm);
                const matchesSubjects = dept.subjects.some(subject => 
                    subject.toLowerCase().includes(searchTerm)
                );
                
                if (!matchesName && !matchesSubjects) {
                    return false;
                }
            }
            
            return true;
        });
    }
    
    updateResultsCount(count) {
        const resultsCount = document.getElementById('resultsCount');
        const resultsContainer = document.getElementById('searchResultsCount');
        
        resultsCount.textContent = count;
        
        if (this.currentFilters.search || this.currentFilters.category !== 'all' || this.currentFilters.letter !== 'all') {
            resultsContainer.classList.add('visible');
        } else {
            resultsContainer.classList.remove('visible');
        }
    }
    
    updateDepartmentCounts() {
        const categories = ['all', 'core', 'stem', 'humanities', 'languages', 'vocational'];
        
        categories.forEach(category => {
            const count = category === 'all' 
                ? this.departmentsData.length 
                : this.departmentsData.filter(dept => dept.category === category).length;
            
            const countElement = document.getElementById(`count-${category}`);
            if (countElement) {
                countElement.textContent = count;
            }
        });
    }
    
    // Loading state management
    showLoadingState() {
        document.getElementById('filterLoading').classList.add('visible');
    }
    
    hideLoadingState() {
        document.getElementById('filterLoading').classList.remove('visible');
    }
    
    // No results state management
    showNoResultsState() {
        document.getElementById('noResults').classList.add('visible');
    }
    
    hideNoResultsState() {
        document.getElementById('noResults').classList.remove('visible');
    }
    
    // Event listeners for additional functionality
    initializeEventListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + F to focus search
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                document.getElementById('departmentSearch').focus();
            }
            
            // Escape to clear filters
            if (e.key === 'Escape') {
                this.clearAllFilters();
            }
        });
        
        // Update alphabet availability based on current filters
        this.updateAlphabetAvailability();
    }
    
    updateAlphabetAvailability() {
        const alphabetLetters = document.querySelectorAll('.alphabet-letter');
        const availableLetters = new Set(
            this.departmentsData.map(dept => dept.letter)
        );
        
        alphabetLetters.forEach(letter => {
            const letterValue = letter.getAttribute('data-letter');
            if (letterValue !== 'all' && !availableLetters.has(letterValue)) {
                letter.classList.add('disabled');
                letter.style.pointerEvents = 'none';
            } else {
                letter.classList.remove('disabled');
                letter.style.pointerEvents = 'auto';
            }
        });
    }
}

// Initialize filter system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const filterSystem = new DepartmentFilterSystem();
});

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DepartmentFilterSystem;
}


class SiteFooter {
    constructor() {
        this.footer = document.querySelector('.site-footer');
        this.backToTopBtn = document.getElementById('backToTop');
        this.currentYearElement = document.getElementById('currentYear');
        this.newsletterForm = document.querySelector('.newsletter-form');
        
        this.scrollThreshold = 300;
        this.isScrolling = false;
        
        this.initialize();
    }

    initialize() {
        // Set current year in copyright
        this.setCurrentYear();
        
        // Set up back to top button
        this.setupBackToTop();
        
        // Set up newsletter form
        this.setupNewsletterForm();
        
        // Set up smooth scrolling for internal links
        this.setupSmoothScrolling();
        
        // Set up intersection observer for animations
        this.setupAnimations();
    }

    setCurrentYear() {
        if (this.currentYearElement) {
            const currentYear = new Date().getFullYear();
            this.currentYearElement.textContent = currentYear;
        }
    }

    setupBackToTop() {
        if (!this.backToTopBtn) return;
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Scroll to top when clicked
        this.backToTopBtn.addEventListener('click', () => {
            this.scrollToTop();
        });
        
        // Keyboard navigation
        this.backToTopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.scrollToTop();
            }
        });
    }

    handleScroll() {
        if (this.isScrolling) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > this.scrollThreshold) {
            this.backToTopBtn.classList.add('visible');
        } else {
            this.backToTopBtn.classList.remove('visible');
        }
    }

    scrollToTop() {
        this.isScrolling = true;
        
        // Add smooth scroll behavior
        const scrollOptions = {
            top: 0,
            behavior: 'smooth'
        };
        
        window.scrollTo(scrollOptions);
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 1000);
    }

    setupNewsletterForm() {
        if (!this.newsletterForm) return;
        
        this.newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSubmit();
        });
        
        // Add input validation
        const emailInput = this.newsletterForm.querySelector('.email-input');
        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validateEmailInput(emailInput);
            });
        }
    }

    validateEmailInput(input) {
        const email = input.value.trim();
        const isValid = this.isValidEmail(email);
        
        if (email === '') {
            input.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        } else if (isValid) {
            input.style.borderColor = '#2ecc71';
        } else {
            input.style.borderColor = '#e74c3c';
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    handleNewsletterSubmit() {
        const emailInput = this.newsletterForm.querySelector('.email-input');
        const submitBtn = this.newsletterForm.querySelector('.subscribe-btn');
        const email = emailInput.value.trim();
        
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            this.subscribeToNewsletter(email);
            
            // Reset form
            emailInput.value = '';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            emailInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        }, 1500);
    }

    subscribeToNewsletter(email) {
        // In a real implementation, this would be an API call
        console.log(`Subscribing email: ${email}`);
        
        // Show success message
        this.showMessage('Thank you for subscribing to our newsletter!', 'success');
        
        // Track newsletter signup
        this.trackNewsletterSignup(email);
    }

    showMessage(message, type) {
        // Remove existing messages
        const existingMessage = this.newsletterForm.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `form-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            padding: 0.75rem;
            margin-top: 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.9rem;
            text-align: center;
            background: ${type === 'success' ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)'};
            border: 1px solid ${type === 'success' ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)'};
            color: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        `;
        
        this.newsletterForm.appendChild(messageElement);
        
        // Auto-remove message after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }

    setupSmoothScrolling() {
        // Add smooth scrolling for internal footer links
        const footerLinks = this.footer.querySelectorAll('a[href^="#"]');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href !== '#') {
                    e.preventDefault();
                    this.scrollToElement(href);
                }
            });
        });
    }

    scrollToElement(selector) {
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const footerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFooterSections();
                }
            });
        }, observerOptions);

        if (this.footer) {
            footerObserver.observe(this.footer);
        }
    }

    animateFooterSections() {
        const sections = this.footer.querySelectorAll('.footer-section');
        
        sections.forEach((section, index) => {
            setTimeout(() => {
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        // Add initial styles for animation
        sections.forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    }

    trackNewsletterSignup(email) {
        // Analytics tracking
        console.log(`Newsletter signup: ${email}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
                'event_category': 'footer',
                'event_label': 'newsletter_subscription'
            });
        }
    }

    // Public method to update contact information
    updateContactInfo(newInfo) {
        if (newInfo.address) {
            const addressElement = this.footer.querySelector('.contact-value');
            if (addressElement) {
                addressElement.textContent = newInfo.address;
            }
        }
        
        if (newInfo.phone) {
            const phoneLink = this.footer.querySelector('a[href^="tel:"]');
            if (phoneLink) {
                phoneLink.textContent = newInfo.phone;
                phoneLink.setAttribute('href', `tel:${newInfo.phone.replace(/\D/g, '')}`);
            }
        }
        
        if (newInfo.email) {
            const emailLink = this.footer.querySelector('a[href^="mailto:"]');
            if (emailLink) {
                emailLink.textContent = newInfo.email;
                emailLink.setAttribute('href', `mailto:${newInfo.email}`);
            }
        }
    }

    // Public method to add social media link
    addSocialMediaLink(platform, url, label) {
        const socialLinksContainer = this.footer.querySelector('.social-links');
        if (!socialLinksContainer) return;
        
        const socialLink = document.createElement('a');
        socialLink.className = `social-link ${platform.toLowerCase()}`;
        socialLink.href = url;
        socialLink.setAttribute('aria-label', label);
        socialLink.target = '_blank';
        socialLink.rel = 'noopener noreferrer';
        
        // Add platform-specific SVG icon
        const iconSvg = this.getSocialIcon(platform);
        socialLink.innerHTML = `${iconSvg}<span class="social-name">${platform}</span>`;
        
        socialLinksContainer.appendChild(socialLink);
    }

    getSocialIcon(platform) {
        const icons = {
            'Facebook': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z"/></svg>',
            'Twitter': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z"/></svg>',
            'Instagram': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'YouTube': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'LinkedIn': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
        };
        
        return icons[platform] || icons['Twitter'];
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScroll());
        
        if (this.backToTopBtn) {
            this.backToTopBtn.removeEventListener('click', () => this.scrollToTop());
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.removeEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
}

// Initialize the footer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const siteFooter = new SiteFooter();
    
    // Make globally available
    window.siteFooter = siteFooter;
});

// Export for use in modules
// export default SiteFooter;