// Header Navigation Functionality
class HeaderNavigation {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mainNav = document.querySelector('.main-nav');
        this.navMenu = document.querySelector('.nav-menu');
        this.isMobileMenuOpen = false;
        
        this.init();
    }

    init() {
        // Add event listener for mobile menu button
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Add event listener for window resize to handle responsive behavior
        window.addEventListener('resize', () => this.handleResize());

        // Add event listeners for navigation links
        this.addNavLinkEventListeners();

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => this.handleClickOutside(e));

        // Handle keyboard navigation
        this.handleKeyboardNavigation();
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.mainNav.classList.add('mobile-active');
        this.mobileMenuBtn.classList.add('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'true');
        
        // Add event listener to close menu when clicking on links
        this.addMobileLinkEventListeners();
    }

    closeMobileMenu() {
        this.mainNav.classList.remove('mobile-active');
        this.mobileMenuBtn.classList.remove('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'false');
        this.isMobileMenuOpen = false;
        
        // Remove mobile link event listeners
        this.removeMobileLinkEventListeners();
    }

    handleResize() {
        // Close mobile menu and reset state when window is resized to desktop size
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    addNavLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Update active state
                this.setActiveLink(link);
                
                // Close mobile menu if open
                if (this.isMobileMenuOpen) {
                    this.closeMobileMenu();
                }
            });
        });
    }

    addMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        this.mobileLinkClickHandler = (e) => {
            // Small delay to allow the click to register before closing menu
            setTimeout(() => {
                this.closeMobileMenu();
            }, 100);
        };
        
        navLinks.forEach(link => {
            link.addEventListener('click', this.mobileLinkClickHandler);
        });
    }

    removeMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        if (this.mobileLinkClickHandler) {
            navLinks.forEach(link => {
                link.removeEventListener('click', this.mobileLinkClickHandler);
            });
        }
    }

    setActiveLink(clickedLink) {
        // Remove active class from all links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to clicked link
        clickedLink.classList.add('active');
    }

    handleClickOutside(e) {
        if (this.isMobileMenuOpen && 
            !this.mainNav.contains(e.target) && 
            !this.mobileMenuBtn.contains(e.target)) {
            this.closeMobileMenu();
        }
    }

    handleKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close mobile menu on Escape key
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
                this.mobileMenuBtn.focus();
            }
        });

        // Trap focus in mobile menu when open
        this.mainNav.addEventListener('keydown', (e) => {
            if (!this.isMobileMenuOpen) return;

            const focusableElements = this.mainNav.querySelectorAll('a[href], button');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }

    // Public method to update active page
    updateActivePage(pageName) {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(pageName)) {
                link.classList.add('active');
            }
        });
    }
}

// Initialize header navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HeaderNavigation();
});

// Export for use in other modules (if using modules)
// export default HeaderNavigation;

// Contact Page Header Interactivity
class ContactPageHeader {
    constructor() {
        this.init();
    }
    
    init() {
        this.initializeFloatingElements();
        this.initializeQuickActions();
        this.initializeEmergencyContact();
        this.initializeScrollIndicator();
        this.initializeBreadcrumbInteractions();
        this.initializeParallaxEffect();
        this.handlePageLoad();
    }
    
    // Floating elements animation
    initializeFloatingElements() {
        const elements = document.querySelectorAll('.floating-element');
        
        elements.forEach((element, index) => {
            // Randomize positions and animations for natural look
            const randomX = Math.random() * 70 + 15;
            const randomY = Math.random() * 70 + 15;
            const randomDelay = Math.random() * 20;
            const randomDuration = Math.random() * 15 + 20;
            
            element.style.left = `${randomX}%`;
            element.style.top = `${randomY}%`;
            element.style.animationDuration = `${randomDuration}s`;
            element.style.animationDelay = `-${randomDelay}s`;
            
            // Add interactive hover effects
            element.addEventListener('mouseenter', () => {
                this.enhanceFloatingElement(element);
            });
            
            element.addEventListener('mouseleave', () => {
                this.resetFloatingElement(element);
            });
            
            // Click interactions
            element.addEventListener('click', () => {
                this.handleElementClick(element);
            });
        });
    }
    
    enhanceFloatingElement(element) {
        const elementType = element.getAttribute('data-element');
        element.style.transform = 'scale(1.3)';
        element.style.opacity = '1';
        element.style.filter = 'drop-shadow(0 8px 20px rgba(0, 0, 0, 0.4))';
        element.style.zIndex = '100';
        element.style.transition = 'all 0.3s ease';
        element.style.cursor = 'pointer';
        
        // Add specific color enhancements based on element type
        const colors = {
            'phone': '#4CAF50',
            'email': '#2196F3',
            'location': '#FF9800',
            'clock': '#9C27B0',
            'chat': '#E91E63'
        };
        
        element.style.background = `rgba(255, 255, 255, 0.2)`;
        element.style.border = `2px solid ${colors[elementType]}`;
    }
    
    resetFloatingElement(element) {
        element.style.transform = '';
        element.style.opacity = '0.8';
        element.style.filter = 'drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3))';
        element.style.zIndex = '';
        element.style.background = 'rgba(255, 255, 255, 0.1)';
        element.style.border = 'none';
        element.style.transition = 'all 0.3s ease';
    }
    
    handleElementClick(element) {
        const elementType = element.getAttribute('data-element');
        
        // Visual feedback
        element.style.transform = 'scale(1.5)';
        element.style.background = 'rgba(255, 255, 255, 0.3)';
        
        setTimeout(() => {
            this.resetFloatingElement(element);
        }, 300);
        
        // Navigate based on element type
        switch(elementType) {
            case 'phone':
                this.scrollToSection('emergency-contact');
                break;
            case 'email':
                this.scrollToSection('contact-form');
                break;
            case 'location':
                this.scrollToSection('campus-location');
                break;
            case 'clock':
                this.showOfficeHours();
                break;
            case 'chat':
                this.openQuickChat();
                break;
        }
    }
    
    // Quick action buttons functionality
    initializeQuickActions() {
        const messageBtn = document.getElementById('quickMessageBtn');
        const callBtn = document.getElementById('quickCallBtn');
        const visitBtn = document.getElementById('quickVisitBtn');
        
        if (messageBtn) {
            messageBtn.addEventListener('click', () => {
                this.handleQuickMessage();
            });
        }
        
        if (callBtn) {
            callBtn.addEventListener('click', () => {
                this.handleQuickCall();
            });
        }
        
        if (visitBtn) {
            visitBtn.addEventListener('click', () => {
                this.handleQuickVisit();
            });
        }
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.altKey) {
                switch(e.key) {
                    case '1':
                        e.preventDefault();
                        this.handleQuickMessage();
                        break;
                    case '2':
                        e.preventDefault();
                        this.handleQuickCall();
                        break;
                    case '3':
                        e.preventDefault();
                        this.handleQuickVisit();
                        break;
                }
            }
        });
    }
    
    handleQuickMessage() {
        const btn = document.getElementById('quickMessageBtn');
        this.animateButtonClick(btn);
        
        // Show sending animation
        const originalText = btn.querySelector('.action-text').textContent;
        btn.querySelector('.action-text').textContent = 'Opening Form...';
        btn.style.background = 'linear-gradient(135deg, #388E3C, #2E7D32)';
        
        setTimeout(() => {
            btn.querySelector('.action-text').textContent = originalText;
            btn.style.background = '';
            
            // Navigate to contact form
            this.scrollToSection('contact-form');
        }, 1000);
    }
    
    handleQuickCall() {
        const btn = document.getElementById('quickCallBtn');
        this.animateButtonClick(btn);
        
        // Simulate calling action
        const originalText = btn.querySelector('.action-text').textContent;
        btn.querySelector('.action-text').textContent = 'Dialing...';
        btn.style.background = 'linear-gradient(135deg, #1976D2, #1565C0)';
        
        setTimeout(() => {
            btn.querySelector('.action-text').textContent = originalText;
            btn.style.background = '';
            
            // In real implementation, this would initiate a phone call
            console.log('Initiating phone call to main office...');
            // window.location.href = 'tel:+1-555-GREENWOOD';
        }, 1500);
    }
    
    handleQuickVisit() {
        const btn = document.getElementById('quickVisitBtn');
        this.animateButtonClick(btn);
        
        // Show scheduling animation
        const originalText = btn.querySelector('.action-text').textContent;
        btn.querySelector('.action-text').textContent = 'Scheduling...';
        btn.style.background = 'linear-gradient(135deg, #F57C00, #EF6C00)';
        
        setTimeout(() => {
            btn.querySelector('.action-text').textContent = originalText;
            btn.style.background = '';
            
            // Navigate to campus visit section
            this.scrollToSection('campus-visit');
        }, 1000);
    }
    
    animateButtonClick(button) {
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = '';
        }, 150);
    }
    
    // Emergency contact functionality
    initializeEmergencyContact() {
        const emergencyLink = document.querySelector('.emergency-link');
        
        if (emergencyLink) {
            emergencyLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleEmergencyCall();
            });
            
            emergencyLink.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.handleEmergencyCall();
                }
            });
        }
    }
    
    handleEmergencyCall() {
        const emergencyBar = document.querySelector('.emergency-contact-bar');
        
        // Visual emergency alert
        emergencyBar.style.animation = 'pulseEmergency 0.5s 3';
        emergencyBar.style.background = 'linear-gradient(135deg, #ff4444, #cc0000)';
        
        // Show confirmation
        const originalNote = document.querySelector('.emergency-note').textContent;
        document.querySelector('.emergency-note').textContent = 'Calling emergency services...';
        
        setTimeout(() => {
            emergencyBar.style.animation = '';
            emergencyBar.style.background = '';
            document.querySelector('.emergency-note').textContent = originalNote;
            
            // In real implementation, this would call emergency services
            console.log('EMERGENCY: Calling campus security and emergency services');
            // window.location.href = 'tel:+1-555-EMERGENCY';
        }, 2000);
    }
    
    // Scroll indicator functionality
    initializeScrollIndicator() {
        const scrollIndicator = document.querySelector('.contact-scroll-indicator');
        
        scrollIndicator.addEventListener('click', () => {
            this.smoothScrollToContent();
        });
        
        // Hide when user starts scrolling
        let scrollTimeout;
        window.addEventListener('scroll', () => {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                if (window.scrollY > 100) {
                    scrollIndicator.style.opacity = '0';
                    scrollIndicator.style.pointerEvents = 'none';
                } else {
                    scrollIndicator.style.opacity = '1';
                    scrollIndicator.style.pointerEvents = 'auto';
                }
            }, 100);
        });
    }
    
    smoothScrollToContent() {
        const contentSection = document.querySelector('.quick-contact-overview') || 
                              document.querySelector('main');
        
        if (contentSection) {
            contentSection.scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
    
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        } else {
            console.log(`Section ${sectionId} not found`);
        }
    }
    
    // Breadcrumb interactions
    initializeBreadcrumbInteractions() {
        const breadcrumbLinks = document.querySelectorAll('.breadcrumb-link');
        
        breadcrumbLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                
                // Add click animation
                link.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    link.style.transform = '';
                }, 150);
                
                // Simulate navigation
                console.log(`Navigating to: ${href}`);
                // window.location.href = href;
            });
        });
    }
    
    // Parallax background effect
    initializeParallaxEffect() {
        const header = document.querySelector('.contact-page-header');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            if (header) {
                header.style.transform = `translateY(${rate}px)`;
            }
        });
    }
    
    // Page load animations
    handlePageLoad() {
        document.body.style.opacity = '0';
        
        setTimeout(() => {
            document.body.style.transition = 'opacity 0.8s ease';
            document.body.style.opacity = '1';
        }, 100);
        
        // Animate elements sequentially
        this.animateHeaderElements();
    }
    
    animateHeaderElements() {
        const elements = [
            '.contact-breadcrumb-nav',
            '.contact-main-title',
            '.contact-intro-text',
            '.contact-quick-actions',
            '.emergency-contact-bar'
        ];
        
        elements.forEach((selector, index) => {
            const element = document.querySelector(selector);
            if (element) {
                setTimeout(() => {
                    element.style.opacity = '0';
                    element.style.transform = 'translateY(30px)';
                    
                    setTimeout(() => {
                        element.style.transition = 'all 0.6s ease';
                        element.style.opacity = '1';
                        element.style.transform = 'translateY(0)';
                    }, 100);
                }, index * 200);
            }
        });
    }
    
    // Utility methods for element interactions
    showOfficeHours() {
        // Create a temporary notification
        this.showNotification('Office Hours: Mon-Fri 8:00 AM - 4:00 PM', 'info');
    }
    
    openQuickChat() {
        this.showNotification('Quick chat feature coming soon!', 'info');
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `contact-notification ${type}`;
        notification.innerHTML = `
            <span class="notification-message">${message}</span>
            <button class="notification-close">×</button>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            color: #333;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            z-index: 1000;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
        
        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const contactHeader = new ContactPageHeader();
});

// Add CSS for notifications
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .notification-close {
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background 0.3s ease;
    }
    
    .notification-close:hover {
        background: #f0f0f0;
    }
`;
document.head.appendChild(notificationStyles);

// Handle responsive behavior
window.addEventListener('resize', () => {
    // Re-initialize floating elements on resize
    const elements = document.querySelectorAll('.floating-element');
    elements.forEach(element => {
        element.style.animation = 'none';
        setTimeout(() => {
            element.style.animation = '';
        }, 10);
    });
});

// Performance optimization
document.addEventListener('visibilitychange', () => {
    const elements = document.querySelectorAll('.floating-element');
    
    if (document.hidden) {
        elements.forEach(element => {
            element.style.animationPlayState = 'paused';
        });
    } else {
        elements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    }
});

// Quick Contact Overview Section Interactivity
class QuickContactOverview {
    constructor() {
        this.init();
    }
    
    init() {
        this.initializeContactCards();
        this.initializeActionButtons();
        this.initializeContactLinks();
        this.initializeStatsAnimation();
        this.initializeScrollAnimations();
    }
    
    // Contact cards interactions
    initializeContactCards() {
        const contactCards = document.querySelectorAll('.contact-method-card');
        
        contactCards.forEach(card => {
            // Click interaction
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.method-action-btn') && !e.target.closest('.contact-link')) {
                    this.expandContactCard(card);
                }
            });
            
            // Keyboard navigation
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    if (!e.target.closest('.method-action-btn') && !e.target.closest('.contact-link')) {
                        this.expandContactCard(card);
                    }
                }
            });
            
            // Hover effects with enhanced visuals
            card.addEventListener('mouseenter', () => {
                this.enhanceCardHover(card);
            });
            
            card.addEventListener('mouseleave', () => {
                this.resetCardHover(card);
            });
        });
    }
    
    expandContactCard(card) {
        // Remove expanded state from all cards
        document.querySelectorAll('.contact-method-card').forEach(c => {
            c.classList.remove('card-expanded');
            c.style.zIndex = '1';
        });
        
        // Add expanded state to clicked card
        card.classList.add('card-expanded');
        card.style.zIndex = '10';
        
        // Animate expansion
        card.style.transform = 'translateY(-15px) scale(1.02)';
        
        // Show additional details
        this.showCardDetails(card);
    }
    
    showCardDetails(card) {
        const method = card.getAttribute('data-method');
        console.log(`Showing details for: ${method}`);
        // In real implementation, this could show more detailed information
    }
    
    enhanceCardHover(card) {
        const method = card.getAttribute('data-method');
        const colors = {
            'phone': '#4CAF50',
            'email': '#2196F3',
            'visit': '#FF9800',
            'hours': '#9C27B0'
        };
        
        card.style.borderColor = colors[method];
        card.style.boxShadow = `0 15px 50px ${colors[method]}20`;
    }
    
    resetCardHover(card) {
        if (!card.classList.contains('card-expanded')) {
            card.style.borderColor = 'transparent';
            card.style.boxShadow = '0 10px 40px rgba(0, 0, 0, 0.08)';
        }
    }
    
    // Action buttons functionality
    initializeActionButtons() {
        const actionButtons = document.querySelectorAll('.method-action-btn');
        
        actionButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = button.getAttribute('data-action');
                const card = button.closest('.contact-method-card');
                const method = card.getAttribute('data-method');
                
                this.handleAction(action, method, button);
            });
        });
    }
    
    handleAction(action, method, button) {
        // Visual feedback
        this.animateButtonClick(button);
        
        switch(action) {
            case 'call':
                this.handlePhoneCall();
                break;
            case 'save-number':
                this.savePhoneNumber();
                break;
            case 'email':
                this.composeEmail();
                break;
            case 'copy-email':
                this.copyEmailAddress();
                break;
            case 'directions':
                this.getDirections();
                break;
            case 'schedule-visit':
                this.scheduleCampusVisit();
                break;
            case 'view-calendar':
                this.viewOfficeCalendar();
                break;
            case 'set-reminder':
                this.setOfficeHoursReminder();
                break;
        }
    }
    
    animateButtonClick(button) {
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = '';
        }, 150);
    }
    
    handlePhoneCall() {
        this.showNotification('Initiating call to main office...', 'info');
        // In real implementation: window.location.href = 'tel:+1-555-473-3669';
    }
    
    savePhoneNumber() {
        const phoneNumber = '(555) 473-3669';
        if (navigator.clipboard) {
            navigator.clipboard.writeText(phoneNumber).then(() => {
                this.showNotification('Phone number copied to clipboard!', 'success');
            }).catch(() => {
                this.showNotification('Failed to copy phone number', 'error');
            });
        } else {
            this.showNotification('Phone number: ' + phoneNumber, 'info');
        }
    }
    
    composeEmail() {
        this.showNotification('Opening email composer...', 'info');
        // In real implementation: window.location.href = 'mailto:info@greenwoodhigh.edu';
    }
    
    copyEmailAddress() {
        const email = 'info@greenwoodhigh.edu';
        if (navigator.clipboard) {
            navigator.clipboard.writeText(email).then(() => {
                this.showNotification('Email address copied to clipboard!', 'success');
            }).catch(() => {
                this.showNotification('Failed to copy email address', 'error');
            });
        } else {
            this.showNotification('Email: ' + email, 'info');
        }
    }
    
    getDirections() {
        this.showNotification('Opening maps with campus directions...', 'info');
        // In real implementation: window.open('https://maps.google.com/?q=123+Education+Boulevard+Greenwood+CA+94201');
    }
    
    scheduleCampusVisit() {
        this.showNotification('Opening campus tour scheduler...', 'info');
        // In real implementation: navigate to tour scheduling page
    }
    
    viewOfficeCalendar() {
        this.showNotification('Loading school calendar...', 'info');
        // In real implementation: open calendar modal or page
    }
    
    setOfficeHoursReminder() {
        if (this.checkCalendarSupport()) {
            this.showNotification('Adding office hours to your calendar...', 'success');
        } else {
            this.showNotification('Office Hours: Mon-Fri 8:00 AM - 4:00 PM', 'info');
        }
    }
    
    checkCalendarSupport() {
        // Basic check for calendar API support
        return 'addEventListener' in window && 'showPicker' in HTMLInputElement.prototype;
    }
    
    // Contact links interactions
    initializeContactLinks() {
        const phoneLinks = document.querySelectorAll('.phone-link');
        const emailLinks = document.querySelectorAll('.email-link');
        
        phoneLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.animateContactLink(link);
                setTimeout(() => {
                    // In real implementation: window.location.href = link.href;
                    this.showNotification('Calling main office...', 'info');
                }, 300);
            });
        });
        
        emailLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.animateContactLink(link);
                setTimeout(() => {
                    // In real implementation: window.location.href = link.href;
                    this.showNotification('Opening email composer...', 'info');
                }, 300);
            });
        });
    }
    
    animateContactLink(link) {
        link.style.transform = 'scale(0.95)';
        link.style.background = '#3498db';
        link.style.color = 'white';
        
        setTimeout(() => {
            link.style.transform = '';
            link.style.background = '';
            link.style.color = '';
        }, 300);
    }
    
    // Stats animation
    initializeStatsAnimation() {
        const statCards = document.querySelectorAll('.contact-stat-card');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateStatCard(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        statCards.forEach(card => {
            observer.observe(card);
        });
    }
    
    animateStatCard(card) {
        const statNumber = card.querySelector('.stat-number');
        const originalText = statNumber.textContent;
        
        // Reset for animation
        statNumber.textContent = '0';
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
            
            // Animate number counting
            this.animateNumber(statNumber, originalText);
        }, 200);
    }
    
    animateNumber(element, target) {
        const duration = 2000;
        const start = 0;
        let current = start;
        
        // Parse target value
        let endValue;
        if (target.includes('/')) {
            // For rating (4.8/5)
            endValue = target;
        } else if (target.includes('%')) {
            // For percentage
            endValue = parseInt(target);
        } else {
            // For time or other numbers
            endValue = target;
        }
        
        const timer = setInterval(() => {
            current += 1;
            if (current >= 100) { // Simple counter for demo
                clearInterval(timer);
                element.textContent = target;
            } else {
                element.textContent = current + (target.includes('%') ? '%' : '');
            }
        }, duration / 100);
    }
    
    // Scroll animations
    initializeScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateOnScroll(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe contact method cards
        document.querySelectorAll('.contact-method-card').forEach(card => {
            observer.observe(card);
        });
        
        // Observe response time card
        const responseCard = document.querySelector('.response-time-card');
        if (responseCard) {
            observer.observe(responseCard);
        }
    }
    
    animateOnScroll(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(40px)';
        
        setTimeout(() => {
            element.style.transition = 'all 0.8s ease';
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Notification system
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `contact-notification ${type}`;
        notification.innerHTML = `
            <span class="notification-message">${message}</span>
            <button class="notification-close">×</button>
        `;
        
        // Add specific styles for contact notifications
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${this.getNotificationColor(type)};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            z-index: 1000;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideInRight 0.3s ease;
            max-width: 300px;
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
        
        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        });
    }
    
    getNotificationColor(type) {
        const colors = {
            'info': '#3498db',
            'success': '#2ecc71',
            'error': '#e74c3c',
            'warning': '#f39c12'
        };
        return colors[type] || colors['info'];
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const quickContact = new QuickContactOverview();
});

// Add CSS for expanded cards and animations
const contactStyles = document.createElement('style');
contactStyles.textContent = `
    .contact-method-card.card-expanded {
        transform: translateY(-15px) scale(1.02) !important;
        box-shadow: 0 25px 80px rgba(0, 0, 0, 0.2) !important;
        z-index: 100 !important;
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .notification-close {
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background 0.3s ease;
        color: white;
    }
    
    .notification-close:hover {
        background: rgba(255, 255, 255, 0.2);
    }
`;
document.head.appendChild(contactStyles);

class SiteFooter {
    constructor() {
        this.footer = document.querySelector('.site-footer');
        this.backToTopBtn = document.getElementById('backToTop');
        this.currentYearElement = document.getElementById('currentYear');
        this.newsletterForm = document.querySelector('.newsletter-form');
        
        this.scrollThreshold = 300;
        this.isScrolling = false;
        
        this.initialize();
    }

    initialize() {
        // Set current year in copyright
        this.setCurrentYear();
        
        // Set up back to top button
        this.setupBackToTop();
        
        // Set up newsletter form
        this.setupNewsletterForm();
        
        // Set up smooth scrolling for internal links
        this.setupSmoothScrolling();
        
        // Set up intersection observer for animations
        this.setupAnimations();
    }

    setCurrentYear() {
        if (this.currentYearElement) {
            const currentYear = new Date().getFullYear();
            this.currentYearElement.textContent = currentYear;
        }
    }

    setupBackToTop() {
        if (!this.backToTopBtn) return;
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Scroll to top when clicked
        this.backToTopBtn.addEventListener('click', () => {
            this.scrollToTop();
        });
        
        // Keyboard navigation
        this.backToTopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.scrollToTop();
            }
        });
    }

    handleScroll() {
        if (this.isScrolling) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > this.scrollThreshold) {
            this.backToTopBtn.classList.add('visible');
        } else {
            this.backToTopBtn.classList.remove('visible');
        }
    }

    scrollToTop() {
        this.isScrolling = true;
        
        // Add smooth scroll behavior
        const scrollOptions = {
            top: 0,
            behavior: 'smooth'
        };
        
        window.scrollTo(scrollOptions);
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 1000);
    }

    setupNewsletterForm() {
        if (!this.newsletterForm) return;
        
        this.newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSubmit();
        });
        
        // Add input validation
        const emailInput = this.newsletterForm.querySelector('.email-input');
        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validateEmailInput(emailInput);
            });
        }
    }

    validateEmailInput(input) {
        const email = input.value.trim();
        const isValid = this.isValidEmail(email);
        
        if (email === '') {
            input.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        } else if (isValid) {
            input.style.borderColor = '#2ecc71';
        } else {
            input.style.borderColor = '#e74c3c';
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    handleNewsletterSubmit() {
        const emailInput = this.newsletterForm.querySelector('.email-input');
        const submitBtn = this.newsletterForm.querySelector('.subscribe-btn');
        const email = emailInput.value.trim();
        
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            this.subscribeToNewsletter(email);
            
            // Reset form
            emailInput.value = '';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            emailInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        }, 1500);
    }

    subscribeToNewsletter(email) {
        // In a real implementation, this would be an API call
        console.log(`Subscribing email: ${email}`);
        
        // Show success message
        this.showMessage('Thank you for subscribing to our newsletter!', 'success');
        
        // Track newsletter signup
        this.trackNewsletterSignup(email);
    }

    showMessage(message, type) {
        // Remove existing messages
        const existingMessage = this.newsletterForm.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `form-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            padding: 0.75rem;
            margin-top: 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.9rem;
            text-align: center;
            background: ${type === 'success' ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)'};
            border: 1px solid ${type === 'success' ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)'};
            color: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        `;
        
        this.newsletterForm.appendChild(messageElement);
        
        // Auto-remove message after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }

    setupSmoothScrolling() {
        // Add smooth scrolling for internal footer links
        const footerLinks = this.footer.querySelectorAll('a[href^="#"]');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href !== '#') {
                    e.preventDefault();
                    this.scrollToElement(href);
                }
            });
        });
    }

    scrollToElement(selector) {
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const footerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFooterSections();
                }
            });
        }, observerOptions);

        if (this.footer) {
            footerObserver.observe(this.footer);
        }
    }

    animateFooterSections() {
        const sections = this.footer.querySelectorAll('.footer-section');
        
        sections.forEach((section, index) => {
            setTimeout(() => {
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        // Add initial styles for animation
        sections.forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    }

    trackNewsletterSignup(email) {
        // Analytics tracking
        console.log(`Newsletter signup: ${email}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
                'event_category': 'footer',
                'event_label': 'newsletter_subscription'
            });
        }
    }

    // Public method to update contact information
    updateContactInfo(newInfo) {
        if (newInfo.address) {
            const addressElement = this.footer.querySelector('.contact-value');
            if (addressElement) {
                addressElement.textContent = newInfo.address;
            }
        }
        
        if (newInfo.phone) {
            const phoneLink = this.footer.querySelector('a[href^="tel:"]');
            if (phoneLink) {
                phoneLink.textContent = newInfo.phone;
                phoneLink.setAttribute('href', `tel:${newInfo.phone.replace(/\D/g, '')}`);
            }
        }
        
        if (newInfo.email) {
            const emailLink = this.footer.querySelector('a[href^="mailto:"]');
            if (emailLink) {
                emailLink.textContent = newInfo.email;
                emailLink.setAttribute('href', `mailto:${newInfo.email}`);
            }
        }
    }

    // Public method to add social media link
    addSocialMediaLink(platform, url, label) {
        const socialLinksContainer = this.footer.querySelector('.social-links');
        if (!socialLinksContainer) return;
        
        const socialLink = document.createElement('a');
        socialLink.className = `social-link ${platform.toLowerCase()}`;
        socialLink.href = url;
        socialLink.setAttribute('aria-label', label);
        socialLink.target = '_blank';
        socialLink.rel = 'noopener noreferrer';
        
        // Add platform-specific SVG icon
        const iconSvg = this.getSocialIcon(platform);
        socialLink.innerHTML = `${iconSvg}<span class="social-name">${platform}</span>`;
        
        socialLinksContainer.appendChild(socialLink);
    }

    getSocialIcon(platform) {
        const icons = {
            'Facebook': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z"/></svg>',
            'Twitter': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z"/></svg>',
            'Instagram': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'YouTube': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'LinkedIn': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
        };
        
        return icons[platform] || icons['Twitter'];
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScroll());
        
        if (this.backToTopBtn) {
            this.backToTopBtn.removeEventListener('click', () => this.scrollToTop());
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.removeEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
}

// Initialize the footer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const siteFooter = new SiteFooter();
    
    // Make globally available
    window.siteFooter = siteFooter;
});

// Export for use in modules
// export default SiteFooter;