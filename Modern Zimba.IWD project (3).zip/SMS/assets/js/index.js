// Header Navigation Functionality
class HeaderNavigation {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mainNav = document.querySelector('.main-nav');
        this.navMenu = document.querySelector('.nav-menu');
        this.isMobileMenuOpen = false;
        
        this.init();
    }

    init() {
        // Add event listener for mobile menu button
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Add event listener for window resize to handle responsive behavior
        window.addEventListener('resize', () => this.handleResize());

        // Add event listeners for navigation links
        this.addNavLinkEventListeners();

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => this.handleClickOutside(e));

        // Handle keyboard navigation
        this.handleKeyboardNavigation();
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.mainNav.classList.add('mobile-active');
        this.mobileMenuBtn.classList.add('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'true');
        
        // Add event listener to close menu when clicking on links
        this.addMobileLinkEventListeners();
    }

    closeMobileMenu() {
        this.mainNav.classList.remove('mobile-active');
        this.mobileMenuBtn.classList.remove('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'false');
        this.isMobileMenuOpen = false;
        
        // Remove mobile link event listeners
        this.removeMobileLinkEventListeners();
    }

    handleResize() {
        // Close mobile menu and reset state when window is resized to desktop size
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    addNavLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Update active state
                this.setActiveLink(link);
                
                // Close mobile menu if open
                if (this.isMobileMenuOpen) {
                    this.closeMobileMenu();
                }
            });
        });
    }

    addMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        this.mobileLinkClickHandler = (e) => {
            // Small delay to allow the click to register before closing menu
            setTimeout(() => {
                this.closeMobileMenu();
            }, 100);
        };
        
        navLinks.forEach(link => {
            link.addEventListener('click', this.mobileLinkClickHandler);
        });
    }

    removeMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        if (this.mobileLinkClickHandler) {
            navLinks.forEach(link => {
                link.removeEventListener('click', this.mobileLinkClickHandler);
            });
        }
    }

    setActiveLink(clickedLink) {
        // Remove active class from all links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to clicked link
        clickedLink.classList.add('active');
    }

    handleClickOutside(e) {
        if (this.isMobileMenuOpen && 
            !this.mainNav.contains(e.target) && 
            !this.mobileMenuBtn.contains(e.target)) {
            this.closeMobileMenu();
        }
    }

    handleKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close mobile menu on Escape key
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
                this.mobileMenuBtn.focus();
            }
        });

        // Trap focus in mobile menu when open
        this.mainNav.addEventListener('keydown', (e) => {
            if (!this.isMobileMenuOpen) return;

            const focusableElements = this.mainNav.querySelectorAll('a[href], button');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }

    // Public method to update active page
    updateActivePage(pageName) {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(pageName)) {
                link.classList.add('active');
            }
        });
    }
}

// Initialize header navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HeaderNavigation();
});

// Export for use in other modules (if using modules)
// export default HeaderNavigation;


class HeroSlider {
    constructor() {
        this.slider = document.querySelector('.hero-slider');
        this.slides = document.querySelectorAll('.slide');
        this.indicators = document.querySelectorAll('.indicator');
        this.prevBtn = document.querySelector('.slider-nav.prev');
        this.nextBtn = document.querySelector('.slider-nav.next');
        this.autoplayToggle = document.querySelector('.autoplay-toggle');
        
        this.currentSlide = 0;
        this.totalSlides = this.slides.length;
        this.isAnimating = false;
        this.autoplayInterval = null;
        this.isAutoplayPaused = false;
        this.autoplayDelay = 5000; // 5 seconds
        
        this.init();
    }

    init() {
        // Set up event listeners
        this.prevBtn.addEventListener('click', () => this.previousSlide());
        this.nextBtn.addEventListener('click', () => this.nextSlide());
        
        this.autoplayToggle.addEventListener('click', () => this.toggleAutoplay());
        
        // Indicator click events
        this.indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => this.goToSlide(index));
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));

        // Pause autoplay on hover
        this.slider.addEventListener('mouseenter', () => this.pauseAutoplay());
        this.slider.addEventListener('mouseleave', () => this.resumeAutoplay());

        // Touch/swipe support for mobile
        this.setupTouchEvents();

        // Start autoplay
        this.startAutoplay();

        // Preload images for better performance
        this.preloadImages();
    }

    startAutoplay() {
        if (this.autoplayInterval) {
            clearInterval(this.autoplayInterval);
        }

        this.autoplayInterval = setInterval(() => {
            if (!this.isAutoplayPaused) {
                this.nextSlide();
            }
        }, this.autoplayDelay);
    }

    toggleAutoplay() {
        this.isAutoplayPaused = !this.isAutoplayPaused;
        
        if (this.isAutoplayPaused) {
            this.autoplayToggle.classList.add('paused');
            this.autoplayToggle.setAttribute('aria-label', 'Play slideshow');
            // Change icon to play
            this.autoplayToggle.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M6 4l12 6-12 6V4z"/>
                </svg>
            `;
        } else {
            this.autoplayToggle.classList.remove('paused');
            this.autoplayToggle.setAttribute('aria-label', 'Pause slideshow');
            // Change icon to pause
            this.autoplayToggle.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M5 4h3v12H5V4zm7 0h3v12h-3V4z"/>
                </svg>
            `;
        }
    }

    pauseAutoplay() {
        this.isAutoplayPaused = true;
        this.autoplayToggle.classList.add('paused');
    }

    resumeAutoplay() {
        if (!this.autoplayToggle.classList.contains('paused')) {
            this.isAutoplayPaused = false;
        }
    }

    nextSlide() {
        if (this.isAnimating) return;
        
        this.isAnimating = true;
        const nextIndex = (this.currentSlide + 1) % this.totalSlides;
        this.changeSlide(nextIndex);
    }

    previousSlide() {
        if (this.isAnimating) return;
        
        this.isAnimating = true;
        const prevIndex = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
        this.changeSlide(prevIndex);
    }

    goToSlide(index) {
        if (this.isAnimating || index === this.currentSlide) return;
        
        this.isAnimating = true;
        this.changeSlide(index);
    }

    changeSlide(newIndex) {
        // Remove active class from current slide and indicator
        this.slides[this.currentSlide].classList.remove('active');
        this.indicators[this.currentSlide].classList.remove('active');
        
        // Add active class to new slide and indicator
        this.slides[newIndex].classList.add('active');
        this.indicators[newIndex].classList.add('active');
        
        // Update current slide index
        this.currentSlide = newIndex;
        
        // Reset animation flag after transition
        setTimeout(() => {
            this.isAnimating = false;
        }, 800);
        
        // Reset autoplay timer
        this.resetAutoplay();
    }

    resetAutoplay() {
        if (this.autoplayInterval) {
            clearInterval(this.autoplayInterval);
        }
        if (!this.isAutoplayPaused) {
            this.startAutoplay();
        }
    }

    handleKeyboard(e) {
        if (e.key === 'ArrowLeft') {
            this.previousSlide();
        } else if (e.key === 'ArrowRight') {
            this.nextSlide();
        } else if (e.key === ' ') {
            e.preventDefault();
            this.toggleAutoplay();
        }
    }

    setupTouchEvents() {
        let touchStartX = 0;
        let touchEndX = 0;

        this.slider.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        this.slider.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe(touchStartX, touchEndX);
        }, { passive: true });
    }

    handleSwipe(startX, endX) {
        const swipeThreshold = 50;
        const diff = startX - endX;

        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                // Swipe left - next slide
                this.nextSlide();
            } else {
                // Swipe right - previous slide
                this.previousSlide();
            }
        }
    }

    preloadImages() {
        const imageUrls = [
            'images/hero/hero-slide1.jpg',
            'images/hero/hero-slide2.jpg',
            'images/hero/hero-slide3.jpg'
        ];

        imageUrls.forEach(url => {
            const img = new Image();
            img.src = url;
        });
    }

    // Public method to manually control the slider
    setSlide(index) {
        if (index >= 0 && index < this.totalSlides) {
            this.goToSlide(index);
        }
    }

    // Public method to get current slide info
    getCurrentSlide() {
        return {
            index: this.currentSlide,
            total: this.totalSlides,
            element: this.slides[this.currentSlide]
        };
    }

    // Clean up method
    destroy() {
        if (this.autoplayInterval) {
            clearInterval(this.autoplayInterval);
        }
        
        // Remove event listeners
        this.prevBtn.removeEventListener('click', () => this.previousSlide());
        this.nextBtn.removeEventListener('click', () => this.nextSlide());
        this.autoplayToggle.removeEventListener('click', () => this.toggleAutoplay());
        
        document.removeEventListener('keydown', (e) => this.handleKeyboard(e));
    }
}

// Initialize the hero slider when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const heroSlider = new HeroSlider();
    
    // Make it globally available for debugging
    window.heroSlider = heroSlider;
});

// Export for use in modules (if using ES6 modules)
// export default HeroSlider;

class IntroductionSection {
    constructor() {
        this.section = document.querySelector('.introduction-section');
        this.statCards = document.querySelectorAll('.stat-card');
        this.counters = document.querySelectorAll('.stat-number');
        this.animationTriggered = false;
        
        this.init();
    }

    init() {
        // Set up intersection observer for animations
        this.setupScrollAnimation();
        
        // Initialize counters when section comes into view
        this.setupCounterAnimation();
        
        // Add click handlers for CTA buttons
        this.setupButtonHandlers();
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationTriggered) {
                    this.animateElements();
                    this.animationTriggered = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    animateElements() {
        // Add visible class to all animated elements
        const animatedElements = this.section.querySelectorAll('.fade-in-up');
        
        animatedElements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add('visible');
            }, index * 200);
        });

        // Start counter animations
        this.startCounters();
    }

    setupCounterAnimation() {
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.startCounters();
                }
            });
        }, { threshold: 0.5 });

        // Observe each stat card for counter animation
        this.statCards.forEach(card => {
            counterObserver.observe(card);
        });
    }

    startCounters() {
        this.counters.forEach(counter => {
            const target = parseInt(counter.parentElement.parentElement.getAttribute('data-counter'));
            this.animateCounter(counter, target);
        });
    }

    animateCounter(element, target) {
        const duration = 2000; // 2 seconds
        const frameRate = 1000 / 60; // 60fps
        const totalFrames = Math.round(duration / frameRate);
        const easeOutQuad = (t) => t * (2 - t);
        
        let frame = 0;
        
        const counter = setInterval(() => {
            frame++;
            const progress = easeOutQuad(frame / totalFrames);
            const currentValue = Math.round(target * progress);
            
            element.textContent = this.formatNumber(currentValue);
            
            if (frame === totalFrames) {
                clearInterval(counter);
                element.textContent = this.formatNumber(target);
            }
        }, frameRate);
    }

    formatNumber(number) {
        if (number >= 1000) {
            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        return number.toString();
    }

    setupButtonHandlers() {
        const primaryBtn = document.querySelector('.btn-primary');
        const secondaryBtn = document.querySelector('.btn-secondary');
        
        if (primaryBtn) {
            primaryBtn.addEventListener('click', () => {
                this.trackButtonClick('learn_more');
                // Smooth scroll to about page or navigate
                window.location.href = 'about.html';
            });
        }
        
        if (secondaryBtn) {
            secondaryBtn.addEventListener('click', () => {
                this.trackButtonClick('schedule_visit');
                // Smooth scroll to contact page or navigate
                window.location.href = 'contact.html';
            });
        }
    }

    trackButtonClick(buttonType) {
        // Analytics tracking - you can integrate with Google Analytics here
        console.log(`Button clicked: ${buttonType}`);
        
        // Example: Send to Google Analytics
        if (typeof gtag !== 'undefined') {
            gtag('event', 'button_click', {
                'event_category': 'introduction_section',
                'event_label': buttonType
            });
        }
    }

    // Public method to manually trigger animations
    triggerAnimations() {
        if (!this.animationTriggered) {
            this.animateElements();
            this.animationTriggered = true;
        }
    }

    // Public method to update statistics
    updateStatistics(newStats) {
        if (newStats.established) {
            const card = document.querySelector('[data-counter]');
            card.setAttribute('data-counter', newStats.established);
        }
        // You can extend this to update other statistics
    }

    // Public method to get current statistics
    getCurrentStatistics() {
        const stats = {};
        this.statCards.forEach(card => {
            const label = card.querySelector('.stat-label').textContent.toLowerCase();
            const value = card.getAttribute('data-counter');
            stats[label] = parseInt(value);
        });
        return stats;
    }
}

// Initialize the introduction section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const introductionSection = new IntroductionSection();
    
    // Make it globally available for debugging
    window.introductionSection = introductionSection;
});

// Add fade-in-up class to elements that should animate
document.addEventListener('DOMContentLoaded', () => {
    const elementsToAnimate = [
        '.section-header',
        '.welcome-message',
        '.motto-card',
        '.stat-card',
        '.cta-buttons'
    ];
    
    elementsToAnimate.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            element.classList.add('fade-in-up');
        });
    });
});

// Export for use in modules (if using ES6 modules)
// export default IntroductionSection;


class AboutPreviewSection {
    constructor() {
        this.section = document.querySelector('.about-preview-section');
        this.cards = document.querySelectorAll('.preview-card');
        this.readMoreBtn = document.getElementById('readMoreBtn');
        this.animationTriggered = false;
        
        this.init();
    }

    init() {
        // Set up intersection observer for scroll animations
        this.setupScrollAnimation();
        
        // Set up card hover effects
        this.setupCardInteractions();
        
        // Set up button click handler
        this.setupButtonHandler();
        
        // Set up keyboard navigation
        this.setupKeyboardNavigation();
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationTriggered) {
                    this.animateCards();
                    this.animationTriggered = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    animateCards() {
        // Animate cards with staggered delay
        this.cards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('visible');
                
                // Add subtle animation to card content
                this.animateCardContent(card);
            }, index * 200);
        });

        // Animate CTA section
        const ctaSection = document.querySelector('.preview-cta');
        if (ctaSection) {
            setTimeout(() => {
                ctaSection.classList.add('visible');
            }, 600);
        }
    }

    animateCardContent(card) {
        const cardTitle = card.querySelector('.card-title');
        const cardText = card.querySelector('.card-text, .values-list');
        
        if (cardTitle) {
            cardTitle.style.opacity = '0';
            cardTitle.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                cardTitle.style.transition = 'all 0.6s ease';
                cardTitle.style.opacity = '1';
                cardTitle.style.transform = 'translateY(0)';
            }, 300);
        }
        
        if (cardText) {
            cardText.style.opacity = '0';
            cardText.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                cardText.style.transition = 'all 0.6s ease 0.2s';
                cardText.style.opacity = '1';
                cardText.style.transform = 'translateY(0)';
            }, 300);
        }
    }

    setupCardInteractions() {
        this.cards.forEach(card => {
            // Click handler for cards
            card.addEventListener('click', () => {
                this.handleCardClick(card);
            });

            // Mouse enter/leave effects
            card.addEventListener('mouseenter', () => {
                this.enhanceCardHover(card);
            });

            card.addEventListener('mouseleave', () => {
                this.resetCardHover(card);
            });

            // Touch device support
            card.addEventListener('touchstart', () => {
                this.enhanceCardHover(card);
            });

            card.addEventListener('touchend', () => {
                setTimeout(() => {
                    this.resetCardHover(card);
                }, 150);
            });
        });
    }

    enhanceCardHover(card) {
        const icon = card.querySelector('.card-icon');
        const title = card.querySelector('.card-title');
        
        if (icon) {
            icon.style.transform = 'scale(1.15) rotate(8deg)';
        }
        
        if (title) {
            title.style.color = this.getCardColor(card);
        }
        
        // Add pulse animation
        card.style.animation = 'cardPulse 2s ease-in-out infinite';
    }

    resetCardHover(card) {
        const icon = card.querySelector('.card-icon');
        const title = card.querySelector('.card-title');
        
        if (icon) {
            icon.style.transform = '';
        }
        
        if (title) {
            title.style.color = '';
        }
        
        card.style.animation = '';
    }

    getCardColor(card) {
        const cardType = card.getAttribute('data-card');
        const colors = {
            'vision': '#3498db',
            'mission': '#e74c3c',
            'values': '#2ecc71'
        };
        return colors[cardType] || '#2c3e50';
    }

    handleCardClick(card) {
        const cardType = card.getAttribute('data-card');
        
        // Add click feedback
        card.style.transform = 'scale(0.95)';
        setTimeout(() => {
            card.style.transform = '';
        }, 150);
        
        // Track analytics
        this.trackCardClick(cardType);
        
        // You could also show a modal or navigate to detailed page
        console.log(`Card clicked: ${cardType}`);
    }

    setupButtonHandler() {
        if (this.readMoreBtn) {
            this.readMoreBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleReadMoreClick();
            });
            
            // Add hover effects
            this.readMoreBtn.addEventListener('mouseenter', () => {
                this.enhanceButtonHover();
            });
            
            this.readMoreBtn.addEventListener('mouseleave', () => {
                this.resetButtonHover();
            });
        }
    }

    enhanceButtonHover() {
        const buttonText = this.readMoreBtn.querySelector('.button-text');
        const buttonArrow = this.readMoreBtn.querySelector('.button-arrow');
        
        if (buttonText) {
            buttonText.style.transform = 'translateX(-5px)';
        }
        
        if (buttonArrow) {
            buttonArrow.style.transform = 'translateX(8px) scale(1.2)';
        }
    }

    resetButtonHover() {
        const buttonText = this.readMoreBtn.querySelector('.button-text');
        const buttonArrow = this.readMoreBtn.querySelector('.button-arrow');
        
        if (buttonText) {
            buttonText.style.transform = '';
        }
        
        if (buttonArrow) {
            buttonArrow.style.transform = '';
        }
    }

    handleReadMoreClick() {
        // Add click feedback
        this.readMoreBtn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.readMoreBtn.style.transform = '';
        }, 150);
        
        // Track analytics
        this.trackButtonClick('read_more');
        
        // Navigate to about page
        setTimeout(() => {
            window.location.href = 'about.html';
        }, 300);
    }

    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Navigate cards with arrow keys when section is in focus
            if (this.section.contains(document.activeElement)) {
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    this.focusNextCard();
                } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    this.focusPreviousCard();
                }
            }
        });
    }

    focusNextCard() {
        const focusedCard = document.activeElement;
        const cardIndex = Array.from(this.cards).indexOf(focusedCard);
        const nextIndex = (cardIndex + 1) % this.cards.length;
        
        if (this.cards[nextIndex]) {
            this.cards[nextIndex].focus();
        }
    }

    focusPreviousCard() {
        const focusedCard = document.activeElement;
        const cardIndex = Array.from(this.cards).indexOf(focusedCard);
        const prevIndex = (cardIndex - 1 + this.cards.length) % this.cards.length;
        
        if (this.cards[prevIndex]) {
            this.cards[prevIndex].focus();
        }
    }

    trackCardClick(cardType) {
        // Analytics tracking
        console.log(`Card clicked: ${cardType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'card_click', {
                'event_category': 'about_preview',
                'event_label': cardType
            });
        }
    }

    trackButtonClick(buttonType) {
        // Analytics tracking
        console.log(`Button clicked: ${buttonType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'button_click', {
                'event_category': 'about_preview',
                'event_label': buttonType
            });
        }
    }

    // Public method to manually trigger animations
    triggerAnimations() {
        if (!this.animationTriggered) {
            this.animateCards();
            this.animationTriggered = true;
        }
    }

    // Public method to update card content
    updateCardContent(cardType, newContent) {
        const card = document.querySelector(`[data-card="${cardType}"]`);
        if (card) {
            const cardText = card.querySelector('.card-text');
            if (cardText) {
                cardText.textContent = newContent;
            }
        }
    }
}

// Initialize the about preview section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const aboutPreview = new AboutPreviewSection();
    
    // Add animation classes to elements
    const cards = document.querySelectorAll('.preview-card');
    const ctaSection = document.querySelector('.preview-cta');
    
    cards.forEach((card, index) => {
        card.classList.add('fade-in-up', `stagger-delay-${index}`);
        card.setAttribute('tabindex', '0'); // Make cards focusable
    });
    
    if (ctaSection) {
        ctaSection.classList.add('fade-in-up', 'stagger-delay-3');
    }
    
    // Make it globally available for debugging
    window.aboutPreview = aboutPreview;
});

// Export for use in modules (if using ES6 modules)
// export default AboutPreviewSection;


class NewsSection {
    constructor() {
        this.section = document.querySelector('.news-section');
        this.newsGrid = document.getElementById('newsGrid');
        this.filterButtons = document.querySelectorAll('.filter-btn');
        this.loadMoreBtn = document.getElementById('loadMoreBtn');
        this.newsCards = document.querySelectorAll('.news-card');
        this.hiddenNews = document.querySelectorAll('.hidden-news');
        
        this.currentFilter = 'all';
        this.visibleCount = 3;
        this.isLoading = false;
        this.animationTriggered = false;
        
        this.init();
    }

    init() {
        // Set up intersection observer for scroll animations
        this.setupScrollAnimation();
        
        // Set up filter functionality
        this.setupFilters();
        
        // Set up load more functionality
        this.setupLoadMore();
        
        // Set up card interactions
        this.setupCardInteractions();
        
        // Initialize hidden news
        this.hideExtraNews();
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationTriggered) {
                    this.animateCards();
                    this.animationTriggered = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    animateCards() {
        // Animate visible news cards with staggered delay
        const visibleCards = Array.from(this.newsCards).slice(0, this.visibleCount);
        
        visibleCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('visible');
                this.animateCardContent(card);
            }, index * 200);
        });

        // Animate filter buttons
        this.filterButtons.forEach((btn, index) => {
            setTimeout(() => {
                btn.classList.add('visible');
            }, index * 100);
        });
    }

    animateCardContent(card) {
        const cardImage = card.querySelector('.card-image');
        const cardContent = card.querySelector('.card-content');
        
        if (cardImage) {
            cardImage.style.opacity = '0';
            cardImage.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                cardImage.style.transition = 'all 0.6s ease';
                cardImage.style.opacity = '1';
                cardImage.style.transform = 'translateY(0)';
            }, 300);
        }
        
        if (cardContent) {
            cardContent.style.opacity = '0';
            cardContent.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                cardContent.style.transition = 'all 0.6s ease 0.2s';
                cardContent.style.opacity = '1';
                cardContent.style.transform = 'translateY(0)';
            }, 300);
        }
    }

    setupFilters() {
        this.filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.getAttribute('data-filter');
                this.applyFilter(filter);
                this.updateActiveFilter(btn);
            });
        });
    }

    applyFilter(filter) {
        this.currentFilter = filter;
        
        // Show loading state
        this.showLoading();
        
        // Hide all cards first with fade out
        this.newsCards.forEach(card => {
            card.classList.add('fade-out');
        });
        
        // After fade out, show filtered cards
        setTimeout(() => {
            this.newsCards.forEach(card => {
                const category = card.getAttribute('data-category');
                
                if (filter === 'all' || category === filter) {
                    card.classList.remove('hidden', 'fade-out');
                } else {
                    card.classList.add('hidden');
                    card.classList.remove('fade-out');
                }
            });
            
            // Check if no results
            this.checkNoResults();
            
            // Hide loading state
            this.hideLoading();
            
            // Reset visible count for filtered results
            this.visibleCount = 3;
            this.hideExtraNews();
            
        }, 300);
    }

    updateActiveFilter(activeBtn) {
        this.filterButtons.forEach(btn => {
            btn.classList.remove('active');
        });
        activeBtn.classList.add('active');
    }

    checkNoResults() {
        const visibleCards = Array.from(this.newsCards).filter(card => 
            !card.classList.contains('hidden')
        );
        
        let noResultsMsg = this.newsGrid.querySelector('.no-results');
        
        if (visibleCards.length === 0) {
            if (!noResultsMsg) {
                noResultsMsg = document.createElement('div');
                noResultsMsg.className = 'no-results';
                noResultsMsg.innerHTML = `
                    <h3>No News Found</h3>
                    <p>There are no news items in this category at the moment.</p>
                `;
                this.newsGrid.appendChild(noResultsMsg);
            }
        } else if (noResultsMsg) {
            noResultsMsg.remove();
        }
    }

    setupLoadMore() {
        if (this.loadMoreBtn) {
            this.loadMoreBtn.addEventListener('click', () => {
                this.loadMoreNews();
            });
        }
    }

    loadMoreNews() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoadMoreLoading();
        
        // Simulate API call delay
        setTimeout(() => {
            this.visibleCount += 3;
            this.showMoreNews();
            this.isLoading = false;
            this.hideLoadMoreLoading();
            
            // Hide load more button if all news are visible
            this.checkLoadMoreVisibility();
        }, 1000);
    }

    showMoreNews() {
        const allVisibleCards = Array.from(this.newsCards).filter(card => 
            !card.classList.contains('hidden')
        );
        
        const cardsToShow = allVisibleCards.slice(this.visibleCount - 3, this.visibleCount);
        
        cardsToShow.forEach((card, index) => {
            setTimeout(() => {
                card.classList.remove('hidden-news');
                card.classList.add('show');
                card.classList.add('visible');
            }, index * 200);
        });
    }

    hideExtraNews() {
        const allVisibleCards = Array.from(this.newsCards).filter(card => 
            !card.classList.contains('hidden')
        );
        
        allVisibleCards.forEach((card, index) => {
            if (index >= this.visibleCount) {
                card.classList.add('hidden-news');
            } else {
                card.classList.remove('hidden-news');
            }
        });
        
        this.checkLoadMoreVisibility();
    }

    checkLoadMoreVisibility() {
        const allVisibleCards = Array.from(this.newsCards).filter(card => 
            !card.classList.contains('hidden')
        );
        
        if (this.visibleCount >= allVisibleCards.length) {
            this.loadMoreBtn.style.display = 'none';
        } else {
            this.loadMoreBtn.style.display = 'inline-flex';
        }
    }

    showLoadMoreLoading() {
        const btnText = this.loadMoreBtn.querySelector('.btn-text');
        const btnSpinner = this.loadMoreBtn.querySelector('.btn-spinner');
        
        btnText.textContent = 'Loading...';
        btnSpinner.style.display = 'inline-block';
        this.loadMoreBtn.disabled = true;
    }

    hideLoadMoreLoading() {
        const btnText = this.loadMoreBtn.querySelector('.btn-text');
        const btnSpinner = this.loadMoreBtn.querySelector('.btn-spinner');
        
        btnText.textContent = 'Load More News';
        btnSpinner.style.display = 'none';
        this.loadMoreBtn.disabled = false;
    }

    showLoading() {
        // Add loading overlay to news grid
        this.newsGrid.style.opacity = '0.7';
        this.newsGrid.style.pointerEvents = 'none';
    }

    hideLoading() {
        this.newsGrid.style.opacity = '1';
        this.newsGrid.style.pointerEvents = 'auto';
    }

    setupCardInteractions() {
        this.newsCards.forEach(card => {
            // Click handler for cards
            card.addEventListener('click', (e) => {
                // Don't trigger if clicking on read more link
                if (!e.target.closest('.read-more-link')) {
                    this.handleCardClick(card);
                }
            });

            // Keyboard navigation
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.handleCardClick(card);
                }
            });
        });
    }

    handleCardClick(card) {
        const link = card.querySelector('.read-more-link');
        if (link) {
            // Add click feedback
            card.style.transform = 'scale(0.98)';
            setTimeout(() => {
                card.style.transform = '';
            }, 150);
            
            // Track analytics
            this.trackCardClick(card);
            
            // Navigate to news article
            window.location.href = link.getAttribute('href');
        }
    }

    trackCardClick(card) {
        const title = card.querySelector('.news-title').textContent;
        const category = card.getAttribute('data-category');
        
        console.log(`News card clicked: ${title} (${category})`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'news_click', {
                'event_category': 'news_section',
                'event_label': title,
                'category': category
            });
        }
    }

    // Public method to manually trigger animations
    triggerAnimations() {
        if (!this.animationTriggered) {
            this.animateCards();
            this.animationTriggered = true;
        }
    }

    // Public method to add new news items
    addNewsItem(newsData) {
        const newsCard = this.createNewsCard(newsData);
        this.newsGrid.appendChild(newsCard);
        
        // Reapply current filter
        this.applyFilter(this.currentFilter);
    }

    createNewsCard(newsData) {
        const card = document.createElement('article');
        card.className = 'news-card hidden-news fade-in-up';
        card.setAttribute('data-category', newsData.category);
        
        card.innerHTML = `
            <div class="card-image">
                <img src="${newsData.image}" alt="${newsData.imageAlt}" class="news-thumbnail">
                <div class="card-badge" data-category="${newsData.category}">${this.formatCategory(newsData.category)}</div>
                <div class="image-overlay"></div>
            </div>
            <div class="card-content">
                <div class="news-meta">
                    <span class="news-date">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
                        </svg>
                        ${newsData.date}
                    </span>
                    <span class="read-time">${newsData.readTime}</span>
                </div>
                <h3 class="news-title">${newsData.title}</h3>
                <p class="news-excerpt">${newsData.excerpt}</p>
                <div class="card-footer">
                    <a href="${newsData.link}" class="read-more-link">
                        Read More
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
                        </svg>
                    </a>
                    <div class="news-tags">
                        ${newsData.tags.map(tag => `<span class="news-tag">${tag}</span>`).join('')}
                    </div>
                </div>
            </div>
        `;
        
        return card;
    }

    formatCategory(category) {
        const formats = {
            'announcements': 'Announcement',
            'events': 'Event',
            'achievements': 'Achievement'
        };
        return formats[category] || category;
    }
}

// Initialize the news section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const newsSection = new NewsSection();
    
    // Add animation classes to elements
    const cards = document.querySelectorAll('.news-card');
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    cards.forEach((card, index) => {
        card.classList.add('fade-in-up');
        card.setAttribute('tabindex', '0'); // Make cards focusable
    });
    
    filterBtns.forEach((btn, index) => {
        btn.classList.add('fade-in-up');
    });
    
    // Make it globally available for debugging
    window.newsSection = newsSection;
});

// Export for use in modules (if using ES6 modules)
// export default NewsSection;

class CommunityVoices {
    constructor() {
        this.section = document.querySelector('.community-voices');
        this.carouselWrapper = document.getElementById('carouselWrapper');
        this.voiceItems = document.querySelectorAll('.voice-item');
        this.dots = document.querySelectorAll('.dot');
        this.prevBtn = document.querySelector('.prev-btn');
        this.nextBtn = document.querySelector('.next-btn');
        this.playToggle = document.getElementById('playToggle');
        
        this.activeIndex = 0;
        this.totalItems = this.voiceItems.length;
        this.isTransitioning = false;
        this.carouselInterval = null;
        this.isCarouselPaused = false;
        this.carouselSpeed = 6000;
        this.animationsStarted = false;
        
        this.initialize();
    }

    initialize() {
        // Set up scroll animations
        this.setupScrollAnimations();
        
        // Set up carousel navigation
        this.setupCarouselNavigation();
        
        // Set up auto-play
        this.setupAutoPlay();
        
        // Set up keyboard controls
        this.setupKeyboardControls();
        
        // Set up touch gestures
        this.setupTouchGestures();
        
        // Set up action buttons
        this.setupActionButtons();
    }

    setupScrollAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationsStarted) {
                    this.startAnimations();
                    this.animationsStarted = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    startAnimations() {
        // Animate section header
        const header = document.querySelector('.voices-header');
        if (header) {
            header.classList.add('is-visible');
        }

        // Animate carousel with delay
        setTimeout(() => {
            const carousel = document.querySelector('.voices-carousel');
            if (carousel) {
                carousel.classList.add('is-visible');
            }
        }, 300);

        // Animate metrics with staggered delay
        const metrics = document.querySelectorAll('.metric-box');
        metrics.forEach((metric, index) => {
            setTimeout(() => {
                metric.classList.add('is-visible');
                this.animateMetricValue(metric.querySelector('.metric-value'));
            }, 500 + (index * 200));
        });

        // Animate action section
        setTimeout(() => {
            const actionSection = document.querySelector('.action-section');
            if (actionSection) {
                actionSection.classList.add('is-visible');
            }
        }, 1200);
    }

    animateMetricValue(element) {
        if (!element) return;
        
        const targetValue = parseInt(element.textContent);
        const animationDuration = 2000;
        const frameInterval = 1000 / 60;
        const totalFrames = Math.round(animationDuration / frameInterval);
        
        let currentFrame = 0;
        
        const valueCounter = setInterval(() => {
            currentFrame++;
            const progress = currentFrame / totalFrames;
            const currentNumber = Math.round(targetValue * progress);
            
            element.textContent = currentNumber + '%';
            
            if (currentFrame === totalFrames) {
                clearInterval(valueCounter);
                element.textContent = targetValue + '%';
            }
        }, frameInterval);
    }

    setupCarouselNavigation() {
        // Previous button
        this.prevBtn.addEventListener('click', () => {
            this.showPreviousItem();
        });

        // Next button
        this.nextBtn.addEventListener('click', () => {
            this.showNextItem();
        });

        // Dot navigation
        this.dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                this.goToItem(index);
            });
        });
    }

    setupAutoPlay() {
        this.startCarousel();
        
        this.playToggle.addEventListener('click', () => {
            this.toggleCarouselPlay();
        });

        // Pause on hover
        this.carouselWrapper.addEventListener('mouseenter', () => {
            this.pauseCarousel();
        });

        this.carouselWrapper.addEventListener('mouseleave', () => {
            this.resumeCarousel();
        });
    }

    startCarousel() {
        if (this.carouselInterval) {
            clearInterval(this.carouselInterval);
        }

        this.carouselInterval = setInterval(() => {
            if (!this.isCarouselPaused) {
                this.showNextItem();
            }
        }, this.carouselSpeed);
    }

    toggleCarouselPlay() {
        this.isCarouselPaused = !this.isCarouselPaused;
        
        if (this.isCarouselPaused) {
            this.playToggle.classList.add('paused-state');
            this.playToggle.setAttribute('aria-label', 'Play carousel');
            // Change to play icon
            this.playToggle.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M6 4l12 6-12 6V4z"/>
                </svg>
            `;
        } else {
            this.playToggle.classList.remove('paused-state');
            this.playToggle.setAttribute('aria-label', 'Pause carousel');
            // Change to pause icon
            this.playToggle.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M5 4h3v12H5V4zm7 0h3v12h-3V4z"/>
                </svg>
            `;
        }
    }

    pauseCarousel() {
        this.isCarouselPaused = true;
        this.playToggle.classList.add('paused-state');
    }

    resumeCarousel() {
        if (!this.playToggle.classList.contains('paused-state')) {
            this.isCarouselPaused = false;
        }
    }

    showNextItem() {
        if (this.isTransitioning) return;
        
        this.isTransitioning = true;
        const nextIndex = (this.activeIndex + 1) % this.totalItems;
        this.changeActiveItem(nextIndex, 'next');
    }

    showPreviousItem() {
        if (this.isTransitioning) return;
        
        this.isTransitioning = true;
        const prevIndex = (this.activeIndex - 1 + this.totalItems) % this.totalItems;
        this.changeActiveItem(prevIndex, 'prev');
    }

    goToItem(index) {
        if (this.isTransitioning || index === this.activeIndex) return;
        
        this.isTransitioning = true;
        const direction = index > this.activeIndex ? 'next' : 'prev';
        this.changeActiveItem(index, direction);
    }

    changeActiveItem(newIndex, direction) {
        // Remove current classes
        this.voiceItems[this.activeIndex].classList.remove('current');
        this.dots[this.activeIndex].classList.remove('active-dot');
        
        // Add direction classes for animation
        this.voiceItems[this.activeIndex].classList.add(direction + '-item');
        
        // Add current classes to new item
        this.voiceItems[newIndex].classList.add('current');
        this.dots[newIndex].classList.add('active-dot');
        
        // Remove direction class after animation
        setTimeout(() => {
            this.voiceItems[this.activeIndex].classList.remove(direction + '-item');
        }, 800);
        
        // Update active index
        this.activeIndex = newIndex;
        
        // Reset transition flag
        setTimeout(() => {
            this.isTransitioning = false;
        }, 800);
        
        // Reset carousel timer
        this.resetCarouselTimer();
        
        // Update screen reader announcement
        this.updateScreenReaderAnnouncement();
    }

    resetCarouselTimer() {
        if (this.carouselInterval) {
            clearInterval(this.carouselInterval);
        }
        if (!this.isCarouselPaused) {
            this.startCarousel();
        }
    }

    updateScreenReaderAnnouncement() {
        const currentItem = this.voiceItems[this.activeIndex];
        const authorName = currentItem.querySelector('.author-name').textContent;
        const authorPosition = currentItem.querySelector('.author-position').textContent;
        
        // Update screen reader announcement
        const announcementArea = document.getElementById('voiceAnnouncement') || this.createAnnouncementArea();
        announcementArea.textContent = `Now showing testimonial from ${authorName}, ${authorPosition}`;
    }

    createAnnouncementArea() {
        const announcementArea = document.createElement('div');
        announcementArea.id = 'voiceAnnouncement';
        announcementArea.setAttribute('aria-live', 'polite');
        announcementArea.setAttribute('aria-atomic', 'true');
        announcementArea.className = 'sr-only';
        this.carouselWrapper.appendChild(announcementArea);
        return announcementArea;
    }

    setupKeyboardControls() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                this.showPreviousItem();
            } else if (e.key === 'ArrowRight') {
                e.preventDefault();
                this.showNextItem();
            } else if (e.key === ' ') {
                e.preventDefault();
                this.toggleCarouselPlay();
            } else if (e.key >= '1' && e.key <= '5') {
                e.preventDefault();
                this.goToItem(parseInt(e.key) - 1);
            }
        });
    }

    setupTouchGestures() {
        let touchStartX = 0;
        let touchEndX = 0;

        this.carouselWrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        this.carouselWrapper.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            this.handleTouchSwipe(touchStartX, touchEndX);
        }, { passive: true });
    }

    handleTouchSwipe(startX, endX) {
        const swipeSensitivity = 50;
        const swipeDistance = startX - endX;

        if (Math.abs(swipeDistance) > swipeSensitivity) {
            if (swipeDistance > 0) {
                // Swipe left - next item
                this.showNextItem();
            } else {
                // Swipe right - previous item
                this.showPreviousItem();
            }
        }
    }

    setupActionButtons() {
        const primaryBtn = document.querySelector('.primary-action');
        const secondaryBtn = document.querySelector('.secondary-action');
        
        if (primaryBtn) {
            primaryBtn.addEventListener('click', () => {
                this.trackAction('begin_journey');
            });
        }
        
        if (secondaryBtn) {
            secondaryBtn.addEventListener('click', () => {
                this.trackAction('plan_visit');
            });
        }
    }

    trackAction(actionType) {
        console.log(`Action taken: ${actionType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'action_click', {
                'event_category': 'community_voices',
                'event_label': actionType
            });
        }
    }

    // Public method to manually start animations
    startAllAnimations() {
        if (!this.animationsStarted) {
            this.startAnimations();
            this.animationsStarted = true;
        }
    }

    // Public method to add new voice item
    addVoiceItem(voiceData) {
        const newItem = this.createVoiceItem(voiceData, this.totalItems);
        this.carouselWrapper.appendChild(newItem);
        
        // Update dots navigation
        this.updateDotsNavigation();
        
        // Reset carousel
        this.resetCarouselTimer();
    }

    createVoiceItem(data, index) {
        const item = document.createElement('div');
        item.className = 'voice-item';
        item.setAttribute('data-item', index + 1);
        
        item.innerHTML = `
            <div class="voice-card">
                <div class="quote-mark">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"/>
                    </svg>
                </div>
                <blockquote class="voice-content">${data.quote}</blockquote>
                <div class="voice-author">
                    <img src="${data.image}" alt="${data.name}" class="author-photo">
                    <div class="author-details">
                        <h4 class="author-name">${data.name}</h4>
                        <p class="author-position">${data.role}</p>
                    </div>
                </div>
                <div class="voice-rating">
                    ${'<span class="rating-star">★</span>'.repeat(data.rating || 5)}
                </div>
            </div>
        `;
        
        return item;
    }

    updateDotsNavigation() {
        const dotsContainer = document.querySelector('.carousel-dots');
        dotsContainer.innerHTML = '';
        
        for (let i = 0; i < this.totalItems; i++) {
            const dot = document.createElement('button');
            dot.className = `dot ${i === this.activeIndex ? 'active-dot' : ''}`;
            dot.setAttribute('data-item', i);
            dot.setAttribute('aria-label', `Go to voice ${i + 1}`);
            
            dot.addEventListener('click', () => {
                this.goToItem(i);
            });
            
            dotsContainer.appendChild(dot);
        }
        
        this.dots = document.querySelectorAll('.dot');
    }

    // Clean up method
    cleanup() {
        if (this.carouselInterval) {
            clearInterval(this.carouselInterval);
        }
        
        // Remove event listeners
        this.prevBtn.removeEventListener('click', () => this.showPreviousItem());
        this.nextBtn.removeEventListener('click', () => this.showNextItem());
        this.playToggle.removeEventListener('click', () => this.toggleCarouselPlay());
        
        document.removeEventListener('keydown', (e) => this.handleKeyboardControls(e));
    }
}

// Initialize the community voices section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const communityVoices = new CommunityVoices();
    
    // Add animation classes to elements
    const animatedElements = [
        '.voices-header',
        '.voices-carousel',
        '.metric-box',
        '.action-section'
    ];
    
    animatedElements.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            element.classList.add('slide-in-up');
        });
    });
    
    // Make globally available
    window.communityVoices = communityVoices;
});

// Screen reader only class
const style = document.createElement('style');
style.textContent = `
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }
`;
document.head.appendChild(style);

class SiteFooter {
    constructor() {
        this.footer = document.querySelector('.site-footer');
        this.backToTopBtn = document.getElementById('backToTop');
        this.currentYearElement = document.getElementById('currentYear');
        this.newsletterForm = document.querySelector('.newsletter-form');
        
        this.scrollThreshold = 300;
        this.isScrolling = false;
        
        this.initialize();
    }

    initialize() {
        // Set current year in copyright
        this.setCurrentYear();
        
        // Set up back to top button
        this.setupBackToTop();
        
        // Set up newsletter form
        this.setupNewsletterForm();
        
        // Set up smooth scrolling for internal links
        this.setupSmoothScrolling();
        
        // Set up intersection observer for animations
        this.setupAnimations();
    }

    setCurrentYear() {
        if (this.currentYearElement) {
            const currentYear = new Date().getFullYear();
            this.currentYearElement.textContent = currentYear;
        }
    }

    setupBackToTop() {
        if (!this.backToTopBtn) return;
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Scroll to top when clicked
        this.backToTopBtn.addEventListener('click', () => {
            this.scrollToTop();
        });
        
        // Keyboard navigation
        this.backToTopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.scrollToTop();
            }
        });
    }

    handleScroll() {
        if (this.isScrolling) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > this.scrollThreshold) {
            this.backToTopBtn.classList.add('visible');
        } else {
            this.backToTopBtn.classList.remove('visible');
        }
    }

    scrollToTop() {
        this.isScrolling = true;
        
        // Add smooth scroll behavior
        const scrollOptions = {
            top: 0,
            behavior: 'smooth'
        };
        
        window.scrollTo(scrollOptions);
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 1000);
    }

    setupNewsletterForm() {
        if (!this.newsletterForm) return;
        
        this.newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSubmit();
        });
        
        // Add input validation
        const emailInput = this.newsletterForm.querySelector('.email-input');
        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validateEmailInput(emailInput);
            });
        }
    }

    validateEmailInput(input) {
        const email = input.value.trim();
        const isValid = this.isValidEmail(email);
        
        if (email === '') {
            input.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        } else if (isValid) {
            input.style.borderColor = '#2ecc71';
        } else {
            input.style.borderColor = '#e74c3c';
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    handleNewsletterSubmit() {
        const emailInput = this.newsletterForm.querySelector('.email-input');
        const submitBtn = this.newsletterForm.querySelector('.subscribe-btn');
        const email = emailInput.value.trim();
        
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            this.subscribeToNewsletter(email);
            
            // Reset form
            emailInput.value = '';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            emailInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        }, 1500);
    }

    subscribeToNewsletter(email) {
        // In a real implementation, this would be an API call
        console.log(`Subscribing email: ${email}`);
        
        // Show success message
        this.showMessage('Thank you for subscribing to our newsletter!', 'success');
        
        // Track newsletter signup
        this.trackNewsletterSignup(email);
    }

    showMessage(message, type) {
        // Remove existing messages
        const existingMessage = this.newsletterForm.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `form-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            padding: 0.75rem;
            margin-top: 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.9rem;
            text-align: center;
            background: ${type === 'success' ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)'};
            border: 1px solid ${type === 'success' ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)'};
            color: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        `;
        
        this.newsletterForm.appendChild(messageElement);
        
        // Auto-remove message after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }

    setupSmoothScrolling() {
        // Add smooth scrolling for internal footer links
        const footerLinks = this.footer.querySelectorAll('a[href^="#"]');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href !== '#') {
                    e.preventDefault();
                    this.scrollToElement(href);
                }
            });
        });
    }

    scrollToElement(selector) {
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const footerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFooterSections();
                }
            });
        }, observerOptions);

        if (this.footer) {
            footerObserver.observe(this.footer);
        }
    }

    animateFooterSections() {
        const sections = this.footer.querySelectorAll('.footer-section');
        
        sections.forEach((section, index) => {
            setTimeout(() => {
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        // Add initial styles for animation
        sections.forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    }

    trackNewsletterSignup(email) {
        // Analytics tracking
        console.log(`Newsletter signup: ${email}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
                'event_category': 'footer',
                'event_label': 'newsletter_subscription'
            });
        }
    }

    // Public method to update contact information
    updateContactInfo(newInfo) {
        if (newInfo.address) {
            const addressElement = this.footer.querySelector('.contact-value');
            if (addressElement) {
                addressElement.textContent = newInfo.address;
            }
        }
        
        if (newInfo.phone) {
            const phoneLink = this.footer.querySelector('a[href^="tel:"]');
            if (phoneLink) {
                phoneLink.textContent = newInfo.phone;
                phoneLink.setAttribute('href', `tel:${newInfo.phone.replace(/\D/g, '')}`);
            }
        }
        
        if (newInfo.email) {
            const emailLink = this.footer.querySelector('a[href^="mailto:"]');
            if (emailLink) {
                emailLink.textContent = newInfo.email;
                emailLink.setAttribute('href', `mailto:${newInfo.email}`);
            }
        }
    }

    // Public method to add social media link
    addSocialMediaLink(platform, url, label) {
        const socialLinksContainer = this.footer.querySelector('.social-links');
        if (!socialLinksContainer) return;
        
        const socialLink = document.createElement('a');
        socialLink.className = `social-link ${platform.toLowerCase()}`;
        socialLink.href = url;
        socialLink.setAttribute('aria-label', label);
        socialLink.target = '_blank';
        socialLink.rel = 'noopener noreferrer';
        
        // Add platform-specific SVG icon
        const iconSvg = this.getSocialIcon(platform);
        socialLink.innerHTML = `${iconSvg}<span class="social-name">${platform}</span>`;
        
        socialLinksContainer.appendChild(socialLink);
    }

    getSocialIcon(platform) {
        const icons = {
            'Facebook': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z"/></svg>',
            'Twitter': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z"/></svg>',
            'Instagram': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'YouTube': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'LinkedIn': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
        };
        
        return icons[platform] || icons['Twitter'];
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScroll());
        
        if (this.backToTopBtn) {
            this.backToTopBtn.removeEventListener('click', () => this.scrollToTop());
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.removeEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
}

// Initialize the footer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const siteFooter = new SiteFooter();
    
    // Make globally available
    window.siteFooter = siteFooter;
});

// Export for use in modules
// export default SiteFooter;