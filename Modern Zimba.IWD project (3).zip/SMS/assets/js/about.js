// Header Navigation Functionality
class HeaderNavigation {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mainNav = document.querySelector('.main-nav');
        this.navMenu = document.querySelector('.nav-menu');
        this.isMobileMenuOpen = false;
        
        this.init();
    }

    init() {
        // Add event listener for mobile menu button
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Add event listener for window resize to handle responsive behavior
        window.addEventListener('resize', () => this.handleResize());

        // Add event listeners for navigation links
        this.addNavLinkEventListeners();

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => this.handleClickOutside(e));

        // Handle keyboard navigation
        this.handleKeyboardNavigation();
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.mainNav.classList.add('mobile-active');
        this.mobileMenuBtn.classList.add('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'true');
        
        // Add event listener to close menu when clicking on links
        this.addMobileLinkEventListeners();
    }

    closeMobileMenu() {
        this.mainNav.classList.remove('mobile-active');
        this.mobileMenuBtn.classList.remove('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'false');
        this.isMobileMenuOpen = false;
        
        // Remove mobile link event listeners
        this.removeMobileLinkEventListeners();
    }

    handleResize() {
        // Close mobile menu and reset state when window is resized to desktop size
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    addNavLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Update active state
                this.setActiveLink(link);
                
                // Close mobile menu if open
                if (this.isMobileMenuOpen) {
                    this.closeMobileMenu();
                }
            });
        });
    }

    addMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        this.mobileLinkClickHandler = (e) => {
            // Small delay to allow the click to register before closing menu
            setTimeout(() => {
                this.closeMobileMenu();
            }, 100);
        };
        
        navLinks.forEach(link => {
            link.addEventListener('click', this.mobileLinkClickHandler);
        });
    }

    removeMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        if (this.mobileLinkClickHandler) {
            navLinks.forEach(link => {
                link.removeEventListener('click', this.mobileLinkClickHandler);
            });
        }
    }

    setActiveLink(clickedLink) {
        // Remove active class from all links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to clicked link
        clickedLink.classList.add('active');
    }

    handleClickOutside(e) {
        if (this.isMobileMenuOpen && 
            !this.mainNav.contains(e.target) && 
            !this.mobileMenuBtn.contains(e.target)) {
            this.closeMobileMenu();
        }
    }

    handleKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close mobile menu on Escape key
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
                this.mobileMenuBtn.focus();
            }
        });

        // Trap focus in mobile menu when open
        this.mainNav.addEventListener('keydown', (e) => {
            if (!this.isMobileMenuOpen) return;

            const focusableElements = this.mainNav.querySelectorAll('a[href], button');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }

    // Public method to update active page
    updateActivePage(pageName) {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(pageName)) {
                link.classList.add('active');
            }
        });
    }
}

// Initialize header navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HeaderNavigation();
});

// Export for use in other modules (if using modules)
// export default HeaderNavigation;


class AboutPageHeader {
    constructor() {
        this.header = document.querySelector('.page-header-section');
        this.stats = document.querySelectorAll('.stat-number');
        this.scrollIndicator = document.querySelector('.scroll-indicator');
        this.backgroundImage = document.querySelector('.background-image');
        
        this.isStatsAnimated = false;
        this.scrollThreshold = 100;
        
        this.init();
    }

    init() {
        // Start stats animation when header is in view
        this.setupIntersectionObserver();
        
        // Set up scroll indicator behavior
        this.setupScrollIndicator();
        
        // Set up background parallax effect
        this.setupParallaxEffect();
        
        // Set up button click handlers
        this.setupButtonHandlers();
        
        // Start floating shapes animation
        this.animateFloatingShapes();
    }

    setupIntersectionObserver() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.5
        };

        const headerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.isStatsAnimated) {
                    this.animateStats();
                    this.isStatsAnimated = true;
                }
            });
        }, observerOptions);

        if (this.header) {
            headerObserver.observe(this.header);
        }
    }

    animateStats() {
        this.stats.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            this.animateCounter(stat, target);
        });
    }

    animateCounter(element, target) {
        const duration = 2000;
        const frameRate = 1000 / 60;
        const totalFrames = Math.round(duration / frameRate);
        const easeOutQuart = (t) => 1 - (--t) * t * t * t;
        
        let frame = 0;
        
        const counter = setInterval(() => {
            frame++;
            const progress = easeOutQuart(frame / totalFrames);
            const currentValue = Math.round(target * progress);
            
            // Add plus sign for numbers over 1000
            if (target >= 1000 && currentValue === target) {
                element.textContent = this.formatNumber(currentValue) + '+';
            } else {
                element.textContent = this.formatNumber(currentValue);
            }
            
            if (frame === totalFrames) {
                clearInterval(counter);
                if (target >= 1000) {
                    element.textContent = this.formatNumber(target) + '+';
                } else {
                    element.textContent = target;
                }
            }
        }, frameRate);
    }

    formatNumber(number) {
        if (number >= 1000) {
            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        return number.toString();
    }

    setupScrollIndicator() {
        window.addEventListener('scroll', () => {
            this.handleScrollBehavior();
        });
        
        // Add click handler to scroll indicator
        if (this.scrollIndicator) {
            this.scrollIndicator.addEventListener('click', () => {
                this.scrollToNextSection();
            });
        }
    }

    handleScrollBehavior() {
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        // Hide scroll indicator when user starts scrolling
        if (scrollY > this.scrollThreshold && this.scrollIndicator) {
            this.scrollIndicator.style.opacity = '0';
            this.scrollIndicator.style.pointerEvents = 'none';
        } else if (this.scrollIndicator) {
            this.scrollIndicator.style.opacity = '1';
            this.scrollIndicator.style.pointerEvents = 'auto';
        }
    }

    scrollToNextSection() {
        const nextSection = document.getElementById('history');
        if (nextSection) {
            nextSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupParallaxEffect() {
        if (!this.backgroundImage) return;
        
        window.addEventListener('scroll', () => {
            this.updateParallax();
        });
    }

    updateParallax() {
        const scrolled = window.pageYOffset;
        const parallaxSpeed = 0.5;
        const transformValue = scrolled * parallaxSpeed;
        
        if (this.backgroundImage) {
            this.backgroundImage.style.transform = `scale(1.05) translateY(${transformValue}px)`;
        }
    }

    setupButtonHandlers() {
        const primaryButton = document.querySelector('.primary-action');
        const secondaryButton = document.querySelector('.secondary-action');
        
        if (primaryButton) {
            primaryButton.addEventListener('click', (e) => {
                this.trackButtonClick('explore_history');
            });
        }
        
        if (secondaryButton) {
            secondaryButton.addEventListener('click', (e) => {
                this.trackButtonClick('schedule_visit');
            });
        }
    }

    trackButtonClick(buttonType) {
        console.log(`Header button clicked: ${buttonType}`);
        
        // Analytics tracking
        if (typeof gtag !== 'undefined') {
            gtag('event', 'button_click', {
                'event_category': 'about_header',
                'event_label': buttonType
            });
        }
    }

    animateFloatingShapes() {
        const shapes = document.querySelectorAll('.floating-shape');
        
        shapes.forEach((shape, index) => {
            // Randomize initial positions and animations
            const randomX = Math.random() * 80 + 10; // 10% to 90%
            const randomY = Math.random() * 80 + 10;
            const randomSize = Math.random() * 40 + 20; // 20px to 60px
            const randomDuration = Math.random() * 4 + 4; // 4s to 8s
            const randomDelay = Math.random() * 2;
            
            shape.style.left = `${randomX}%`;
            shape.style.top = `${randomY}%`;
            shape.style.width = `${randomSize}px`;
            shape.style.height = `${randomSize}px`;
            shape.style.animationDuration = `${randomDuration}s`;
            shape.style.animationDelay = `${randomDelay}s`;
        });
    }

    // Public method to update header content
    updateHeaderContent(newContent) {
        if (newContent.title) {
            const titleElement = document.querySelector('.page-main-title');
            if (titleElement) {
                titleElement.textContent = newContent.title;
            }
        }
        
        if (newContent.intro) {
            const introElement = document.querySelector('.page-intro-text');
            if (introElement) {
                introElement.textContent = newContent.intro;
            }
        }
        
        if (newContent.stats) {
            this.updateStats(newContent.stats);
        }
    }

    updateStats(newStats) {
        this.stats.forEach((stat, index) => {
            if (newStats[index]) {
                const target = parseInt(newStats[index]);
                stat.setAttribute('data-count', target);
                stat.textContent = '0';
                
                // Re-animate if stats were already animated
                if (this.isStatsAnimated) {
                    this.animateCounter(stat, target);
                }
            }
        });
    }

    // Public method to change background image
    changeBackgroundImage(newImageUrl) {
        if (this.backgroundImage) {
            // Create a new image to preload
            const newImage = new Image();
            newImage.src = newImageUrl;
            
            newImage.onload = () => {
                // Add fade transition
                this.backgroundImage.style.opacity = '0';
                
                setTimeout(() => {
                    this.backgroundImage.src = newImageUrl;
                    this.backgroundImage.style.opacity = '1';
                }, 300);
            };
        }
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScrollBehavior());
        window.removeEventListener('scroll', () => this.updateParallax());
        
        if (this.scrollIndicator) {
            this.scrollIndicator.removeEventListener('click', () => this.scrollToNextSection());
        }
    }
}

// Global function for button onclick
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Initialize the about page header when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const aboutHeader = new AboutPageHeader();
    
    // Make globally available for debugging and external control
    window.aboutHeader = aboutHeader;
});

// Export for use in modules
// export default AboutPageHeader;


class HistoryTimeline {
    constructor() {
        this.timelineSection = document.querySelector('.history-timeline-section');
        this.timelineTrack = document.querySelector('.timeline-track');
        this.timelineItems = document.querySelectorAll('.timeline-item');
        this.navButtons = {
            prev: document.querySelector('.prev-btn'),
            next: document.querySelector('.next-btn')
        };
        this.decadeFilters = document.querySelectorAll('.decade-filter');
        this.progressFill = document.querySelector('.progress-fill');
        this.viewMoreBtn = document.getElementById('viewMoreHistory');
        
        this.currentIndex = 0;
        this.totalItems = this.timelineItems.length;
        this.isAnimating = false;
        this.animationDuration = 500;
        this.autoPlayInterval = null;
        this.autoPlayDelay = 5000;
        this.isAutoPlayPaused = false;
        
        this.init();
    }

    init() {
        // Set up intersection observer for animations
        this.setupScrollAnimation();
        
        // Set up navigation
        this.setupNavigation();
        
        // Set up decade filters
        this.setupDecadeFilters();
        
        // Set up auto-play
        this.setupAutoPlay();
        
        // Set up view more button
        this.setupViewMoreButton();
        
        // Initialize first item as active
        this.setActiveItem(this.currentIndex);
        
        // Update progress bar
        this.updateProgress();
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.3
        };

        const timelineObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateTimelineItems();
                }
            });
        }, observerOptions);

        if (this.timelineSection) {
            timelineObserver.observe(this.timelineSection);
        }
    }

    animateTimelineItems() {
        this.timelineItems.forEach((item, index) => {
            setTimeout(() => {
                item.classList.add('animate-in');
            }, index * 200);
        });
    }

    setupNavigation() {
        // Previous button
        if (this.navButtons.prev) {
            this.navButtons.prev.addEventListener('click', () => {
                this.previousItem();
            });
        }

        // Next button
        if (this.navButtons.next) {
            this.navButtons.next.addEventListener('click', () => {
                this.nextItem();
            });
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                this.previousItem();
            } else if (e.key === 'ArrowRight') {
                e.preventDefault();
                this.nextItem();
            }
        });

        // Touch/swipe support
        this.setupTouchEvents();
    }

    setupDecadeFilters() {
        this.decadeFilters.forEach(filter => {
            filter.addEventListener('click', () => {
                const decade = filter.getAttribute('data-decade');
                this.filterByDecade(decade);
                this.updateActiveFilter(filter);
            });
        });
    }

    filterByDecade(decade) {
        if (decade === 'all') {
            // Show all items
            this.timelineItems.forEach(item => {
                item.style.display = 'flex';
            });
            this.currentIndex = 0;
        } else {
            // Filter items by decade
            let firstVisibleIndex = -1;
            
            this.timelineItems.forEach((item, index) => {
                const itemDecade = item.getAttribute('data-decade');
                
                if (itemDecade === decade) {
                    item.style.display = 'flex';
                    if (firstVisibleIndex === -1) {
                        firstVisibleIndex = index;
                    }
                } else {
                    item.style.display = 'none';
                }
            });
            
            // Set first visible item as active
            if (firstVisibleIndex !== -1) {
                this.currentIndex = firstVisibleIndex;
            }
        }
        
        this.setActiveItem(this.currentIndex);
        this.updateProgress();
    }

    updateActiveFilter(activeFilter) {
        this.decadeFilters.forEach(filter => {
            filter.classList.remove('active');
        });
        activeFilter.classList.add('active');
    }

    setupAutoPlay() {
        this.startAutoPlay();
        
        // Pause auto-play on hover
        this.timelineSection.addEventListener('mouseenter', () => {
            this.pauseAutoPlay();
        });

        this.timelineSection.addEventListener('mouseleave', () => {
            this.resumeAutoPlay();
        });

        // Pause auto-play on focus
        this.timelineSection.addEventListener('focusin', () => {
            this.pauseAutoPlay();
        });

        this.timelineSection.addEventListener('focusout', () => {
            this.resumeAutoPlay();
        });
    }

    startAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
        }

        this.autoPlayInterval = setInterval(() => {
            if (!this.isAutoPlayPaused) {
                this.nextItem();
            }
        }, this.autoPlayDelay);
    }

    pauseAutoPlay() {
        this.isAutoPlayPaused = true;
    }

    resumeAutoPlay() {
        this.isAutoPlayPaused = false;
    }

    setupTouchEvents() {
        let touchStartX = 0;
        let touchEndX = 0;

        this.timelineTrack.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        this.timelineTrack.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe(touchStartX, touchEndX);
        }, { passive: true });
    }

    handleSwipe(startX, endX) {
        const swipeThreshold = 50;
        const diff = startX - endX;

        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                // Swipe left - next item
                this.nextItem();
            } else {
                // Swipe right - previous item
                this.previousItem();
            }
        }
    }

    setupViewMoreButton() {
        if (this.viewMoreBtn) {
            this.viewMoreBtn.addEventListener('click', () => {
                this.handleViewMoreClick();
            });
        }
    }

    handleViewMoreClick() {
        // Add click animation
        this.viewMoreBtn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.viewMoreBtn.style.transform = '';
        }, 150);

        // Track analytics
        this.trackViewMoreClick();

        // In a real implementation, this would load more history items
        // or navigate to a dedicated history page
        console.log('View more history clicked');
        
        // Example: Show hidden timeline items
        this.loadMoreHistoryItems();
    }

    loadMoreHistoryItems() {
        // This would typically involve an API call to load more items
        // For now, we'll just show a message
        const existingMessage = this.timelineSection.querySelector('.load-more-message');
        if (!existingMessage) {
            const message = document.createElement('div');
            message.className = 'load-more-message';
            message.style.cssText = `
                text-align: center;
                padding: 2rem;
                color: #7f8c8d;
                font-style: italic;
            `;
            message.textContent = 'Additional historical records would be loaded here...';
            this.viewMoreBtn.parentNode.insertBefore(message, this.viewMoreBtn);
            
            // Hide the button after click
            this.viewMoreBtn.style.display = 'none';
        }
    }

    previousItem() {
        if (this.isAnimating) return;
        
        this.isAnimating = true;
        const prevIndex = (this.currentIndex - 1 + this.totalItems) % this.totalItems;
        this.setActiveItem(prevIndex);
        
        setTimeout(() => {
            this.isAnimating = false;
        }, this.animationDuration);
    }

    nextItem() {
        if (this.isAnimating) return;
        
        this.isAnimating = true;
        const nextIndex = (this.currentIndex + 1) % this.totalItems;
        this.setActiveItem(nextIndex);
        
        setTimeout(() => {
            this.isAnimating = false;
        }, this.animationDuration);
    }

    setActiveItem(index) {
        // Remove active class from all items
        this.timelineItems.forEach(item => {
            item.classList.remove('active');
        });

        // Add active class to current item
        if (this.timelineItems[index]) {
            this.timelineItems[index].classList.add('active');
            this.currentIndex = index;
        }

        // Update navigation buttons state
        this.updateNavButtons();
        
        // Update progress bar
        this.updateProgress();
        
        // Center the active item (for horizontal layout)
        this.centerActiveItem();
        
        // Reset auto-play timer
        this.resetAutoPlay();
    }

    centerActiveItem() {
        if (this.timelineTrack && this.timelineItems[this.currentIndex]) {
            const item = this.timelineItems[this.currentIndex];
            const trackRect = this.timelineTrack.getBoundingClientRect();
            const itemRect = item.getBoundingClientRect();
            const scrollLeft = item.offsetLeft - (trackRect.width - itemRect.width) / 2;
            
            this.timelineTrack.scrollTo({
                left: scrollLeft,
                behavior: 'smooth'
            });
        }
    }

    updateNavButtons() {
        if (this.navButtons.prev) {
            this.navButtons.prev.disabled = this.currentIndex === 0;
        }
        
        if (this.navButtons.next) {
            this.navButtons.next.disabled = this.currentIndex === this.totalItems - 1;
        }
    }

    updateProgress() {
        if (this.progressFill) {
            const progress = ((this.currentIndex + 1) / this.totalItems) * 100;
            this.progressFill.style.width = `${progress}%`;
        }
    }

    resetAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
        }
        if (!this.isAutoPlayPaused) {
            this.startAutoPlay();
        }
    }

    trackViewMoreClick() {
        console.log('View more history button clicked');
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'view_more_click', {
                'event_category': 'history_timeline',
                'event_label': 'explore_full_history'
            });
        }
    }

    // Public method to add new timeline item
    addTimelineItem(year, data) {
        const newItem = this.createTimelineItem(year, data, this.totalItems);
        this.timelineTrack.appendChild(newItem);
        
        // Update items collection
        this.timelineItems = document.querySelectorAll('.timeline-item');
        this.totalItems = this.timelineItems.length;
        
        // Re-apply animations
        setTimeout(() => {
            newItem.classList.add('animate-in');
        }, 100);
    }

    createTimelineItem(year, data, index) {
        const item = document.createElement('div');
        item.className = 'timeline-item';
        item.setAttribute('data-year', year);
        item.setAttribute('data-decade', year.substring(0, 3) + '0');
        
        item.innerHTML = `
            <div class="timeline-marker">
                <div class="marker-circle"></div>
                <div class="marker-line"></div>
            </div>
            <div class="timeline-content">
                <div class="year-badge">${year}</div>
                <div class="content-card">
                    <div class="card-image">
                        <img src="${data.image}" alt="${data.imageAlt}" class="history-image">
                        <div class="image-overlay"></div>
                    </div>
                    <div class="card-body">
                        <h3 class="event-title">${data.title}</h3>
                        <p class="event-description">${data.description}</p>
                        <div class="event-stats">
                            ${data.stats.map(stat => `
                                <div class="stat">
                                    <span class="stat-number">${stat.number}</span>
                                    <span class="stat-label">${stat.label}</span>
                                </div>
                            `).join('')}
                        </div>
                        <div class="achievement-tag">${data.tag}</div>
                    </div>
                </div>
            </div>
        `;
        
        return item;
    }

    // Public method to go to specific year
    goToYear(year) {
        const targetIndex = Array.from(this.timelineItems).findIndex(item => 
            item.getAttribute('data-year') === year.toString()
        );
        
        if (targetIndex !== -1) {
            this.setActiveItem(targetIndex);
        }
    }

    // Clean up method
    destroy() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
        }
        
        // Remove event listeners
        if (this.navButtons.prev) {
            this.navButtons.prev.removeEventListener('click', () => this.previousItem());
        }
        
        if (this.navButtons.next) {
            this.navButtons.next.removeEventListener('click', () => this.nextItem());
        }
        
        if (this.viewMoreBtn) {
            this.viewMoreBtn.removeEventListener('click', () => this.handleViewMoreClick());
        }
        
        document.removeEventListener('keydown', (e) => this.handleKeyboardNavigation(e));
    }
}

// Initialize the history timeline when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const historyTimeline = new HistoryTimeline();
    
    // Make globally available for debugging and external control
    window.historyTimeline = historyTimeline;
});

// Export for use in modules
// export default HistoryTimeline;


class CoreValuesSection {
    constructor() {
        this.section = document.querySelector('.core-values-section');
        this.valueCards = document.querySelectorAll('.value-card');
        this.filterButtons = document.querySelectorAll('.filter-btn');
        this.spotlight = document.getElementById('valueSpotlight');
        this.spotlightExamples = document.getElementById('spotlightExamples');
        this.valuesGrid = document.getElementById('valuesGrid');
        
        this.currentFilter = 'all';
        this.animationTriggered = false;
        
        // Value examples data
        this.valueExamples = {
            excellence: [
                {
                    title: "Academic Honors Program",
                    description: "Advanced courses and enrichment opportunities for high-achieving students"
                },
                {
                    title: "Professional Development",
                    description: "Continuous training and growth opportunities for our teaching staff"
                },
                {
                    title: "Quality Standards",
                    description: "Rigorous academic standards and comprehensive assessment systems"
                }
            ],
            integrity: [
                {
                    title: "Honor Code System",
                    description: "Student-led honor council promoting academic honesty and ethical behavior"
                },
                {
                    title: "Transparent Communication",
                    description: "Open and honest dialogue between administration, staff, students, and parents"
                },
                {
                    title: "Ethical Decision Making",
                    description: "Framework for making principled choices in complex situations"
                }
            ],
            innovation: [
                {
                    title: "STEM Innovation Lab",
                    description: "State-of-the-art facility for robotics, coding, and engineering projects"
                },
                {
                    title: "Digital Learning Platform",
                    description: "Integrated technology tools enhancing classroom instruction and collaboration"
                },
                {
                    title: "Creative Problem Solving",
                    description: "Curriculum focused on design thinking and innovative solution development"
                }
            ],
            community: [
                {
                    title: "Family Engagement Programs",
                    description: "Regular workshops, events, and volunteer opportunities for families"
                },
                {
                    title: "Peer Mentoring System",
                    description: "Older students guiding and supporting younger students' transition"
                },
                {
                    title: "Community Partnerships",
                    description: "Collaborations with local organizations and businesses for mutual benefit"
                }
            ],
            diversity: [
                {
                    title: "Cultural Celebration Events",
                    description: "Annual festivals and activities celebrating diverse backgrounds and traditions"
                },
                {
                    title: "Inclusive Curriculum",
                    description: "Learning materials representing multiple perspectives and experiences"
                },
                {
                    title: "Diversity Training",
                    description: "Workshops and seminars promoting cultural competence and understanding"
                }
            ],
            responsibility: [
                {
                    title: "Environmental Stewardship",
                    description: "Green initiatives, recycling programs, and sustainability education"
                },
                {
                    title: "Service Learning Projects",
                    description: "Community service integrated with academic learning objectives"
                },
                {
                    title: "Leadership Development",
                    description: "Programs teaching accountability, decision-making, and civic responsibility"
                }
            ]
        };
        
        this.init();
    }

    init() {
        // Set up intersection observer for animations
        this.setupScrollAnimation();
        
        // Set up filter functionality
        this.setupFilters();
        
        // Set up card interactions
        this.setupCardInteractions();
        
        // Set up button click handlers
        this.setupButtonHandlers();
        
        // Initialize spotlight with default content
        this.updateSpotlight('all');
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationTriggered) {
                    this.animateCards();
                    this.animationTriggered = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    animateCards() {
        this.valueCards.forEach(card => {
            card.classList.add('animate-in');
        });
    }

    setupFilters() {
        this.filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.getAttribute('data-filter');
                this.applyFilter(filter);
                this.updateActiveFilter(btn);
                this.updateSpotlight(filter);
            });
        });
    }

    applyFilter(filter) {
        this.currentFilter = filter;
        
        if (filter === 'all') {
            // Show all cards
            this.valueCards.forEach(card => {
                card.style.display = 'block';
                card.style.opacity = '1';
                card.style.transform = 'scale(1)';
            });
        } else {
            // Filter cards
            this.valueCards.forEach(card => {
                const valueType = card.getAttribute('data-value');
                
                if (valueType === filter) {
                    card.style.display = 'block';
                    card.style.opacity = '1';
                    card.style.transform = 'scale(1)';
                } else {
                    card.style.opacity = '0.3';
                    card.style.transform = 'scale(0.95)';
                    
                    // Hide completely after transition
                    setTimeout(() => {
                        if (this.currentFilter === filter && valueType !== filter) {
                            card.style.display = 'none';
                        }
                    }, 300);
                }
            });
        }
        
        // Animate grid layout change
        this.animateGridLayout();
    }

    animateGridLayout() {
        this.valuesGrid.style.transform = 'scale(0.98)';
        setTimeout(() => {
            this.valuesGrid.style.transform = 'scale(1)';
        }, 150);
    }

    updateActiveFilter(activeBtn) {
        this.filterButtons.forEach(btn => {
            btn.classList.remove('active');
        });
        activeBtn.classList.add('active');
    }

    updateSpotlight(filter) {
        if (filter === 'all') {
            this.showDefaultSpotlight();
        } else {
            this.showValueSpotlight(filter);
        }
    }

    showDefaultSpotlight() {
        this.spotlight.innerHTML = `
            <div class="spotlight-content">
                <div class="spotlight-icon">💡</div>
                <h3 class="spotlight-title">Our Values in Action</h3>
                <p class="spotlight-description">
                    Select a value to learn how we integrate these principles into daily school life and decision-making processes.
                </p>
                <div class="spotlight-examples">
                    <div class="example-item">
                        <div class="example-title">Comprehensive Approach</div>
                        <p class="example-description">
                            Our six core values work together to create a holistic educational environment where students thrive academically, socially, and emotionally.
                        </p>
                    </div>
                </div>
            </div>
        `;
        
        // Update spotlight border color
        this.spotlight.style.borderLeftColor = '#3498db';
    }

    showValueSpotlight(value) {
        const examples = this.valueExamples[value];
        const valueColors = {
            excellence: '#e74c3c',
            integrity: '#3498db',
            innovation: '#9b59b6',
            community: '#2ecc71',
            diversity: '#f39c12',
            responsibility: '#1abc9c'
        };
        
        const valueTitles = {
            excellence: 'Excellence in Practice',
            integrity: 'Integrity in Action',
            innovation: 'Innovation at Work',
            community: 'Community Building',
            diversity: 'Diversity & Inclusion',
            responsibility: 'Responsibility in Action'
        };
        
        const valueDescriptions = {
            excellence: 'How we pursue the highest standards in everything we do',
            integrity: 'Building trust through ethical conduct and transparency',
            innovation: 'Embracing creativity and new approaches to learning',
            community: 'Fostering strong, supportive relationships and collaboration',
            diversity: 'Creating an inclusive environment that celebrates differences',
            responsibility: 'Being accountable and making positive contributions'
        };

        this.spotlight.innerHTML = `
            <div class="spotlight-content">
                <div class="spotlight-icon" style="background: ${valueColors[value]}">${this.getValueIcon(value)}</div>
                <h3 class="spotlight-title">${valueTitles[value]}</h3>
                <p class="spotlight-description">${valueDescriptions[value]}</p>
                <div class="spotlight-examples">
                    ${examples.map(example => `
                        <div class="example-item" style="border-left-color: ${valueColors[value]}">
                            <div class="example-title">${example.title}</div>
                            <p class="example-description">${example.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        // Update spotlight border color
        this.spotlight.style.borderLeftColor = valueColors[value];
    }

    getValueIcon(value) {
        const icons = {
            excellence: '⭐',
            integrity: '🛡️',
            innovation: '💡',
            community: '🤝',
            diversity: '🌍',
            responsibility: '📝'
        };
        return icons[value] || '💡';
    }

    setupCardInteractions() {
        this.valueCards.forEach(card => {
            // Click handler for cards
            card.addEventListener('click', () => {
                const value = card.getAttribute('data-value');
                this.handleCardClick(card, value);
            });

            // Keyboard navigation
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const value = card.getAttribute('data-value');
                    this.handleCardClick(card, value);
                }
            });

            // Touch device support
            card.addEventListener('touchstart', () => {
                card.classList.add('touch-active');
            });

            card.addEventListener('touchend', () => {
                setTimeout(() => {
                    card.classList.remove('touch-active');
                }, 150);
            });
        });
    }

    handleCardClick(card, value) {
        // Add click feedback
        card.style.transform = 'scale(0.95)';
        setTimeout(() => {
            card.style.transform = '';
        }, 150);

        // Apply filter for this value
        this.applyFilter(value);
        
        // Update active filter button
        const correspondingFilter = Array.from(this.filterButtons).find(btn => 
            btn.getAttribute('data-filter') === value
        );
        if (correspondingFilter) {
            this.updateActiveFilter(correspondingFilter);
        }
        
        // Update spotlight
        this.updateSpotlight(value);
        
        // Track analytics
        this.trackValueClick(value);
    }

    setupButtonHandlers() {
        const primaryBtn = document.querySelector('.primary-cta');
        const secondaryBtn = document.querySelector('.secondary-cta');
        
        if (primaryBtn) {
            primaryBtn.addEventListener('click', () => {
                this.trackButtonClick('values_in_academics');
            });
        }
        
        if (secondaryBtn) {
            secondaryBtn.addEventListener('click', () => {
                this.trackButtonClick('community_impact');
            });
        }
    }

    trackValueClick(value) {
        console.log(`Value card clicked: ${value}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'value_click', {
                'event_category': 'core_values',
                'event_label': value
            });
        }
    }

    trackButtonClick(buttonType) {
        console.log(`CTA button clicked: ${buttonType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'button_click', {
                'event_category': 'core_values',
                'event_label': buttonType
            });
        }
    }

    // Public method to add new value
    addValue(valueData) {
        const newCard = this.createValueCard(valueData);
        this.valuesGrid.appendChild(newCard);
        
        // Update cards collection
        this.valueCards = document.querySelectorAll('.value-card');
        
        // Add to examples data
        this.valueExamples[valueData.key] = valueData.examples;
        
        // Add new filter button
        this.addFilterButton(valueData);
        
        // Re-apply current filter
        this.applyFilter(this.currentFilter);
    }

    createValueCard(valueData) {
        const card = document.createElement('div');
        card.className = 'value-card';
        card.setAttribute('data-value', valueData.key);
        card.tabIndex = 0; // Make focusable
        
        card.innerHTML = `
            <div class="card-inner">
                <div class="value-icon">
                    ${valueData.iconSvg}
                </div>
                <h3 class="value-title">${valueData.title}</h3>
                <p class="value-description">${valueData.description}</p>
                <div class="value-highlight"></div>
            </div>
        `;
        
        // Add event listeners
        card.addEventListener('click', () => {
            this.handleCardClick(card, valueData.key);
        });
        
        return card;
    }

    addFilterButton(valueData) {
        const filterContainer = document.querySelector('.value-filters');
        const newButton = document.createElement('button');
        newButton.className = 'filter-btn';
        newButton.setAttribute('data-filter', valueData.key);
        newButton.textContent = valueData.title;
        
        newButton.addEventListener('click', () => {
            this.applyFilter(valueData.key);
            this.updateActiveFilter(newButton);
            this.updateSpotlight(valueData.key);
        });
        
        filterContainer.appendChild(newButton);
        this.filterButtons = document.querySelectorAll('.filter-btn');
    }

    // Public method to update value examples
    updateValueExamples(valueKey, newExamples) {
        if (this.valueExamples[valueKey]) {
            this.valueExamples[valueKey] = newExamples;
            
            // Update spotlight if this value is currently selected
            if (this.currentFilter === valueKey) {
                this.updateSpotlight(valueKey);
            }
        }
    }

    // Clean up method
    destroy() {
        this.valueCards.forEach(card => {
            card.removeEventListener('click', () => this.handleCardClick);
            card.removeEventListener('keydown', () => this.handleKeyboard);
        });
        
        this.filterButtons.forEach(btn => {
            btn.removeEventListener('click', () => this.applyFilter);
        });
    }
}

// Initialize the core values section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const coreValues = new CoreValuesSection();
    
    // Make globally available for debugging and external control
    window.coreValues = coreValues;
});

// Export for use in modules
// export default CoreValuesSection;

class LeadershipSection {
    constructor() {
        this.section = document.querySelector('.leadership-section');
        this.leaderCards = document.querySelectorAll('.leader-card');
        this.navDots = document.querySelectorAll('.nav-dot');
        this.statNumbers = document.querySelectorAll('.stat-number');
        this.viewProfileBtns = document.querySelectorAll('.view-profile-btn');
        this.closeProfileBtns = document.querySelectorAll('.close-profile-btn');
        this.modal = document.getElementById('leaderModal');
        this.modalClose = document.getElementById('modalClose');
        
        this.animationTriggered = false;
        this.activeCardIndex = 0;
        
        // Leader data for modal
        this.leaderData = {
            principal: {
                name: "Dr. Sarah Mitchell",
                role: "School Principal",
                image: "images/leadership/principal.jpg",
                qualifications: [
                    "Ed.D. Educational Leadership - Harvard University",
                    "M.A. Curriculum Development - Stanford University",
                    "B.A. Education - University of California"
                ],
                bio: "With over 25 years in educational leadership, Dr. Mitchell brings a wealth of experience in fostering academic excellence and building inclusive learning communities. Her research focuses on innovative teaching methodologies and student-centered learning.",
                philosophy: "Every student possesses unique talents and potential. Our role is to create an environment where these talents can flourish through personalized learning, mentorship, and opportunities for growth.",
                achievements: [
                    "National Excellence in Education Award 2022",
                    "Published 3 books on educational innovation",
                    "Led school to 98% college acceptance rate",
                    "Established community outreach programs serving 5,000+ students"
                ],
                contact: "s.mitchell@greenwoodhigh.edu"
            },
            'vice-principal': {
                name: "Mr. James Rodriguez",
                role: "Vice Principal",
                image: "images/leadership/vice-principal.jpg",
                qualifications: [
                    "M.Ed. School Administration - Columbia University",
                    "B.S. Mathematics - MIT",
                    "Certified School Administrator"
                ],
                bio: "James Rodriguez brings 20 years of educational experience with a focus on student development and operational excellence. His background in mathematics informs his data-driven approach to school improvement and student success.",
                responsibilities: [
                    "Student discipline and behavior management",
                    "Staff development and evaluation",
                    "Academic program coordination",
                    "School operations and scheduling",
                    "Parent and community relations"
                ],
                expertise: [
                    "Data Analysis",
                    "Curriculum Design",
                    "Teacher Mentoring",
                    "STEM Education",
                    "Operational Management"
                ],
                contact: "j.rodriguez@greenwoodhigh.edu"
            },
            'academic-dean': {
                name: "Dr. Emily Chen",
                role: "Academic Dean",
                image: "images/leadership/academic-dean.jpg",
                qualifications: [
                    "Ph.D. Educational Psychology - University of Pennsylvania",
                    "M.A. Instructional Design - Carnegie Mellon",
                    "B.S. Cognitive Science - UC Berkeley"
                ],
                bio: "Dr. Chen is a visionary educator with 18 years of experience in curriculum development and academic innovation. Her research on learning sciences has influenced teaching practices across multiple school districts.",
                vision: "To create a dynamic learning ecosystem where students develop critical thinking skills, digital literacy, and global competence through interdisciplinary approaches and real-world applications.",
                initiatives: [
                    "Implemented project-based learning across all grades",
                    "Developed digital literacy certification program",
                    "Established international student exchange program",
                    "Launched AI and robotics curriculum",
                    "Created interdisciplinary STEM pathways"
                ],
                contact: "e.chen@greenwoodhigh.edu"
            }
        };
        
        this.init();
    }

    init() {
        // Set up intersection observer for animations
        this.setupScrollAnimation();
        
        // Set up card interactions
        this.setupCardInteractions();
        
        // Set up navigation dots
        this.setupNavigation();
        
        // Set up modal functionality
        this.setupModal();
        
        // Set up contact link interactions
        this.setupContactInteractions();
        
        // Initialize stats animation
        this.animateStats();
    }

    setupScrollAnimation() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
        };

        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animationTriggered) {
                    this.animateSection();
                    this.animationTriggered = true;
                }
            });
        }, observerOptions);

        if (this.section) {
            sectionObserver.observe(this.section);
        }
    }

    animateSection() {
        // Animate stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('animate-in');
            }, index * 200);
        });

        // Animate leader cards
        this.leaderCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('animate-in');
            }, 600 + (index * 200));
        });
    }

    animateStats() {
        this.statNumbers.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            this.animateCounter(stat, target);
        });
    }

    animateCounter(element, target) {
        const duration = 2000;
        const frameRate = 1000 / 60;
        const totalFrames = Math.round(duration / frameRate);
        const easeOutQuart = (t) => 1 - (--t) * t * t * t;
        
        let frame = 0;
        
        const counter = setInterval(() => {
            frame++;
            const progress = easeOutQuart(frame / totalFrames);
            const currentValue = Math.round(target * progress);
            
            element.textContent = currentValue;
            
            if (frame === totalFrames) {
                clearInterval(counter);
                element.textContent = target;
            }
        }, frameRate);
    }

    setupCardInteractions() {
        this.leaderCards.forEach((card, index) => {
            // Click to flip card
            card.addEventListener('click', (e) => {
                // Don't flip if clicking on buttons
                if (!e.target.closest('button')) {
                    this.flipCard(card);
                    this.setActiveCard(index);
                }
            });

            // Keyboard navigation
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.flipCard(card);
                    this.setActiveCard(index);
                }
            });

            // View profile button
            const viewBtn = card.querySelector('.view-profile-btn');
            if (viewBtn) {
                viewBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const leaderRole = viewBtn.getAttribute('data-leader');
                    this.openModal(leaderRole);
                });
            }

            // Close profile button
            const closeBtn = card.querySelector('.close-profile-btn');
            if (closeBtn) {
                closeBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.flipCard(card);
                });
            }
        });
    }

    flipCard(card) {
        card.classList.toggle('flipped');
        
        // Add accessibility attributes
        const isFlipped = card.classList.contains('flipped');
        const frontContent = card.querySelector('.card-front');
        const backContent = card.querySelector('.card-back');
        
        if (isFlipped) {
            frontContent.setAttribute('aria-hidden', 'true');
            backContent.setAttribute('aria-hidden', 'false');
        } else {
            frontContent.setAttribute('aria-hidden', 'false');
            backContent.setAttribute('aria-hidden', 'true');
        }
    }

    setupNavigation() {
        this.navDots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                this.setActiveCard(index);
            });
        });

        // Keyboard navigation for dots
        this.navDots.forEach((dot, index) => {
            dot.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.setActiveCard(index);
                }
            });
        });
    }

    setActiveCard(index) {
        // Reset all cards to front position
        this.leaderCards.forEach(card => {
            card.classList.remove('flipped');
            const frontContent = card.querySelector('.card-front');
            const backContent = card.querySelector('.card-back');
            frontContent.setAttribute('aria-hidden', 'false');
            backContent.setAttribute('aria-hidden', 'true');
        });

        // Update active dot
        this.navDots.forEach(dot => {
            dot.classList.remove('active');
        });
        
        if (this.navDots[index]) {
            this.navDots[index].classList.add('active');
        }

        this.activeCardIndex = index;
        
        // Scroll card into view on mobile
        if (window.innerWidth < 768) {
            this.leaderCards[index].scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }
    }

    setupModal() {
        // Close modal when clicking close button
        if (this.modalClose) {
            this.modalClose.addEventListener('click', () => {
                this.closeModal();
            });
        }

        // Close modal when clicking outside content
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal.classList.contains('active')) {
                this.closeModal();
            }
        });
    }

    openModal(leaderRole) {
        const leader = this.leaderData[leaderRole];
        if (!leader) return;

        // Update modal content
        const modalTitle = document.getElementById('modalLeaderName');
        const modalBody = document.getElementById('modalBody');

        modalTitle.textContent = leader.name;

        modalBody.innerHTML = `
            <div class="modal-leader-info">
                <div class="modal-image">
                    <img src="${leader.image}" alt="${leader.name}" class="modal-photo">
                </div>
                <div class="modal-details">
                    <p class="modal-role">${leader.role}</p>
                    <div class="modal-qualifications">
                        <h4>Qualifications</h4>
                        <ul>
                            ${leader.qualifications.map(qual => `<li>${qual}</li>`).join('')}
                        </ul>
                    </div>
                    <div class="modal-bio">
                        <h4>About</h4>
                        <p>${leader.bio}</p>
                    </div>
                    ${leader.philosophy ? `
                        <div class="modal-philosophy">
                            <h4>Educational Philosophy</h4>
                            <p>"${leader.philosophy}"</p>
                        </div>
                    ` : ''}
                    ${leader.vision ? `
                        <div class="modal-vision">
                            <h4>Academic Vision</h4>
                            <p>"${leader.vision}"</p>
                        </div>
                    ` : ''}
                    ${leader.achievements ? `
                        <div class="modal-achievements">
                            <h4>Key Achievements</h4>
                            <ul>
                                ${leader.achievements.map(achievement => `<li>${achievement}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    ${leader.responsibilities ? `
                        <div class="modal-responsibilities">
                            <h4>Key Responsibilities</h4>
                            <ul>
                                ${leader.responsibilities.map(responsibility => `<li>${responsibility}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    ${leader.initiatives ? `
                        <div class="modal-initiatives">
                            <h4>Recent Initiatives</h4>
                            <ul>
                                ${leader.initiatives.map(initiative => `<li>${initiative}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    ${leader.expertise ? `
                        <div class="modal-expertise">
                            <h4>Areas of Expertise</h4>
                            <div class="expertise-tags">
                                ${leader.expertise.map(exp => `<span class="expertise-tag">${exp}</span>`).join('')}
                            </div>
                        </div>
                    ` : ''}
                    <div class="modal-contact">
                        <h4>Contact</h4>
                        <a href="mailto:${leader.contact}" class="contact-email">${leader.contact}</a>
                    </div>
                </div>
            </div>
        `;

        // Show modal
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden';

        // Track analytics
        this.trackModalOpen(leaderRole);
    }

    closeModal() {
        this.modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    setupContactInteractions() {
        const contactLinks = document.querySelectorAll('.contact-link');
        
        contactLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const linkType = link.classList.contains('email-link') ? 'email' :
                               link.classList.contains('calendar-link') ? 'calendar' : 'blog';
                this.trackContactClick(linkType);
            });
        });
    }

    trackModalOpen(leaderRole) {
        console.log(`Modal opened for: ${leaderRole}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'modal_open', {
                'event_category': 'leadership',
                'event_label': leaderRole
            });
        }
    }

    trackContactClick(linkType) {
        console.log(`Contact link clicked: ${linkType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'contact_click', {
                'event_category': 'leadership',
                'event_label': linkType
            });
        }
    }

    // Public method to add new leader
    addLeader(leaderData) {
        const newCard = this.createLeaderCard(leaderData);
        const grid = document.getElementById('leadershipGrid');
        grid.appendChild(newCard);
        
        // Update cards collection
        this.leaderCards = document.querySelectorAll('.leader-card');
        
        // Add new navigation dot
        this.addNavigationDot(leaderData.role);
        
        // Add to leader data
        this.leaderData[leaderData.key] = leaderData;
        
        // Re-apply animations
        setTimeout(() => {
            newCard.classList.add('animate-in');
        }, 100);
    }

    createLeaderCard(leaderData) {
        const card = document.createElement('div');
        card.className = 'leader-card';
        card.setAttribute('data-role', leaderData.key);
        card.tabIndex = 0;
        
        card.innerHTML = `
            <div class="card-front">
                <div class="leader-image">
                    <img src="${leaderData.image}" alt="${leaderData.name}" class="profile-photo">
                    <div class="image-overlay"></div>
                    <div class="role-badge">${leaderData.role}</div>
                </div>
                <div class="leader-info">
                    <h3 class="leader-name">${leaderData.name}</h3>
                    <p class="leader-role">${leaderData.title}</p>
                    <div class="leader-qualifications">
                        ${leaderData.qualifications.map(qual => 
                            `<span class="qualification">${qual}</span>`
                        ).join('')}
                    </div>
                    <button class="view-profile-btn" data-leader="${leaderData.key}">
                        View Full Profile
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="card-back">
                <div class="profile-details">
                    <h4 class="detail-title">About ${leaderData.name.split(' ')[0]}</h4>
                    <p class="leader-bio">${leaderData.bio}</p>
                    ${leaderData.details}
                </div>
                <button class="close-profile-btn" data-leader="${leaderData.key}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                    </svg>
                </button>
            </div>
        `;
        
        // Add event listeners
        this.attachCardEventListeners(card, leaderData.key);
        
        return card;
    }

    attachCardEventListeners(card, leaderKey) {
        card.addEventListener('click', (e) => {
            if (!e.target.closest('button')) {
                this.flipCard(card);
            }
        });

        const viewBtn = card.querySelector('.view-profile-btn');
        const closeBtn = card.querySelector('.close-profile-btn');
        
        if (viewBtn) {
            viewBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.openModal(leaderKey);
            });
        }
        
        if (closeBtn) {
            closeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.flipCard(card);
            });
        }
    }

    addNavigationDot(role) {
        const navContainer = document.querySelector('.leadership-navigation');
        const newDot = document.createElement('button');
        newDot.className = 'nav-dot';
        newDot.setAttribute('data-role', role);
        newDot.setAttribute('aria-label', `View ${role} profile`);
        
        const dotIndex = this.navDots.length;
        newDot.addEventListener('click', () => {
            this.setActiveCard(dotIndex);
        });
        
        navContainer.appendChild(newDot);
        this.navDots = document.querySelectorAll('.nav-dot');
    }

    // Public method to update leader information
    updateLeader(leaderKey, updatedData) {
        if (this.leaderData[leaderKey]) {
            this.leaderData[leaderKey] = { ...this.leaderData[leaderKey], ...updatedData };
            
            // If modal is open for this leader, update it
            const modalTitle = document.getElementById('modalLeaderName');
            if (modalTitle && modalTitle.textContent === this.leaderData[leaderKey].name) {
                this.openModal(leaderKey);
            }
        }
    }

    // Clean up method
    destroy() {
        this.leaderCards.forEach(card => {
            card.removeEventListener('click', () => this.flipCard);
        });
        
        this.navDots.forEach(dot => {
            dot.removeEventListener('click', () => this.setActiveCard);
        });
        
        if (this.modalClose) {
            this.modalClose.removeEventListener('click', () => this.closeModal);
        }
        
        document.removeEventListener('keydown', (e) => this.handleEscapeKey(e));
    }
}

// Initialize the leadership section when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const leadershipSection = new LeadershipSection();
    
    // Make globally available for debugging and external control
    window.leadershipSection = leadershipSection;
});

// Export for use in modules
// export default LeadershipSection;

class SiteFooter {
    constructor() {
        this.footer = document.querySelector('.site-footer');
        this.backToTopBtn = document.getElementById('backToTop');
        this.currentYearElement = document.getElementById('currentYear');
        this.newsletterForm = document.querySelector('.newsletter-form');
        
        this.scrollThreshold = 300;
        this.isScrolling = false;
        
        this.initialize();
    }

    initialize() {
        // Set current year in copyright
        this.setCurrentYear();
        
        // Set up back to top button
        this.setupBackToTop();
        
        // Set up newsletter form
        this.setupNewsletterForm();
        
        // Set up smooth scrolling for internal links
        this.setupSmoothScrolling();
        
        // Set up intersection observer for animations
        this.setupAnimations();
    }

    setCurrentYear() {
        if (this.currentYearElement) {
            const currentYear = new Date().getFullYear();
            this.currentYearElement.textContent = currentYear;
        }
    }

    setupBackToTop() {
        if (!this.backToTopBtn) return;
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Scroll to top when clicked
        this.backToTopBtn.addEventListener('click', () => {
            this.scrollToTop();
        });
        
        // Keyboard navigation
        this.backToTopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.scrollToTop();
            }
        });
    }

    handleScroll() {
        if (this.isScrolling) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > this.scrollThreshold) {
            this.backToTopBtn.classList.add('visible');
        } else {
            this.backToTopBtn.classList.remove('visible');
        }
    }

    scrollToTop() {
        this.isScrolling = true;
        
        // Add smooth scroll behavior
        const scrollOptions = {
            top: 0,
            behavior: 'smooth'
        };
        
        window.scrollTo(scrollOptions);
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 1000);
    }

    setupNewsletterForm() {
        if (!this.newsletterForm) return;
        
        this.newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSubmit();
        });
        
        // Add input validation
        const emailInput = this.newsletterForm.querySelector('.email-input');
        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validateEmailInput(emailInput);
            });
        }
    }

    validateEmailInput(input) {
        const email = input.value.trim();
        const isValid = this.isValidEmail(email);
        
        if (email === '') {
            input.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        } else if (isValid) {
            input.style.borderColor = '#2ecc71';
        } else {
            input.style.borderColor = '#e74c3c';
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    handleNewsletterSubmit() {
        const emailInput = this.newsletterForm.querySelector('.email-input');
        const submitBtn = this.newsletterForm.querySelector('.subscribe-btn');
        const email = emailInput.value.trim();
        
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            this.subscribeToNewsletter(email);
            
            // Reset form
            emailInput.value = '';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            emailInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        }, 1500);
    }

    subscribeToNewsletter(email) {
        // In a real implementation, this would be an API call
        console.log(`Subscribing email: ${email}`);
        
        // Show success message
        this.showMessage('Thank you for subscribing to our newsletter!', 'success');
        
        // Track newsletter signup
        this.trackNewsletterSignup(email);
    }

    showMessage(message, type) {
        // Remove existing messages
        const existingMessage = this.newsletterForm.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `form-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            padding: 0.75rem;
            margin-top: 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.9rem;
            text-align: center;
            background: ${type === 'success' ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)'};
            border: 1px solid ${type === 'success' ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)'};
            color: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        `;
        
        this.newsletterForm.appendChild(messageElement);
        
        // Auto-remove message after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }

    setupSmoothScrolling() {
        // Add smooth scrolling for internal footer links
        const footerLinks = this.footer.querySelectorAll('a[href^="#"]');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href !== '#') {
                    e.preventDefault();
                    this.scrollToElement(href);
                }
            });
        });
    }

    scrollToElement(selector) {
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const footerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFooterSections();
                }
            });
        }, observerOptions);

        if (this.footer) {
            footerObserver.observe(this.footer);
        }
    }

    animateFooterSections() {
        const sections = this.footer.querySelectorAll('.footer-section');
        
        sections.forEach((section, index) => {
            setTimeout(() => {
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        // Add initial styles for animation
        sections.forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    }

    trackNewsletterSignup(email) {
        // Analytics tracking
        console.log(`Newsletter signup: ${email}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
                'event_category': 'footer',
                'event_label': 'newsletter_subscription'
            });
        }
    }

    // Public method to update contact information
    updateContactInfo(newInfo) {
        if (newInfo.address) {
            const addressElement = this.footer.querySelector('.contact-value');
            if (addressElement) {
                addressElement.textContent = newInfo.address;
            }
        }
        
        if (newInfo.phone) {
            const phoneLink = this.footer.querySelector('a[href^="tel:"]');
            if (phoneLink) {
                phoneLink.textContent = newInfo.phone;
                phoneLink.setAttribute('href', `tel:${newInfo.phone.replace(/\D/g, '')}`);
            }
        }
        
        if (newInfo.email) {
            const emailLink = this.footer.querySelector('a[href^="mailto:"]');
            if (emailLink) {
                emailLink.textContent = newInfo.email;
                emailLink.setAttribute('href', `mailto:${newInfo.email}`);
            }
        }
    }

    // Public method to add social media link
    addSocialMediaLink(platform, url, label) {
        const socialLinksContainer = this.footer.querySelector('.social-links');
        if (!socialLinksContainer) return;
        
        const socialLink = document.createElement('a');
        socialLink.className = `social-link ${platform.toLowerCase()}`;
        socialLink.href = url;
        socialLink.setAttribute('aria-label', label);
        socialLink.target = '_blank';
        socialLink.rel = 'noopener noreferrer';
        
        // Add platform-specific SVG icon
        const iconSvg = this.getSocialIcon(platform);
        socialLink.innerHTML = `${iconSvg}<span class="social-name">${platform}</span>`;
        
        socialLinksContainer.appendChild(socialLink);
    }

    getSocialIcon(platform) {
        const icons = {
            'Facebook': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z"/></svg>',
            'Twitter': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z"/></svg>',
            'Instagram': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'YouTube': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'LinkedIn': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
        };
        
        return icons[platform] || icons['Twitter'];
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScroll());
        
        if (this.backToTopBtn) {
            this.backToTopBtn.removeEventListener('click', () => this.scrollToTop());
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.removeEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
}

// Initialize the footer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const siteFooter = new SiteFooter();
    
    // Make globally available
    window.siteFooter = siteFooter;
});

// Export for use in modules
// export default SiteFooter;