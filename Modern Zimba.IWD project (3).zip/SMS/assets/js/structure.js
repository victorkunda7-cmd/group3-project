// Header Navigation Functionality
class HeaderNavigation {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mainNav = document.querySelector('.main-nav');
        this.navMenu = document.querySelector('.nav-menu');
        this.isMobileMenuOpen = false;
        
        this.init();
    }

    init() {
        // Add event listener for mobile menu button
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Add event listener for window resize to handle responsive behavior
        window.addEventListener('resize', () => this.handleResize());

        // Add event listeners for navigation links
        this.addNavLinkEventListeners();

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => this.handleClickOutside(e));

        // Handle keyboard navigation
        this.handleKeyboardNavigation();
    }

    toggleMobileMenu() {
        this.isMobileMenuOpen = !this.isMobileMenuOpen;
        
        if (this.isMobileMenuOpen) {
            this.openMobileMenu();
        } else {
            this.closeMobileMenu();
        }
    }

    openMobileMenu() {
        this.mainNav.classList.add('mobile-active');
        this.mobileMenuBtn.classList.add('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'true');
        
        // Add event listener to close menu when clicking on links
        this.addMobileLinkEventListeners();
    }

    closeMobileMenu() {
        this.mainNav.classList.remove('mobile-active');
        this.mobileMenuBtn.classList.remove('active');
        this.mobileMenuBtn.setAttribute('aria-expanded', 'false');
        this.isMobileMenuOpen = false;
        
        // Remove mobile link event listeners
        this.removeMobileLinkEventListeners();
    }

    handleResize() {
        // Close mobile menu and reset state when window is resized to desktop size
        if (window.innerWidth > 768 && this.isMobileMenuOpen) {
            this.closeMobileMenu();
        }
    }

    addNavLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Update active state
                this.setActiveLink(link);
                
                // Close mobile menu if open
                if (this.isMobileMenuOpen) {
                    this.closeMobileMenu();
                }
            });
        });
    }

    addMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        this.mobileLinkClickHandler = (e) => {
            // Small delay to allow the click to register before closing menu
            setTimeout(() => {
                this.closeMobileMenu();
            }, 100);
        };
        
        navLinks.forEach(link => {
            link.addEventListener('click', this.mobileLinkClickHandler);
        });
    }

    removeMobileLinkEventListeners() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        if (this.mobileLinkClickHandler) {
            navLinks.forEach(link => {
                link.removeEventListener('click', this.mobileLinkClickHandler);
            });
        }
    }

    setActiveLink(clickedLink) {
        // Remove active class from all links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to clicked link
        clickedLink.classList.add('active');
    }

    handleClickOutside(e) {
        if (this.isMobileMenuOpen && 
            !this.mainNav.contains(e.target) && 
            !this.mobileMenuBtn.contains(e.target)) {
            this.closeMobileMenu();
        }
    }

    handleKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close mobile menu on Escape key
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
                this.mobileMenuBtn.focus();
            }
        });

        // Trap focus in mobile menu when open
        this.mainNav.addEventListener('keydown', (e) => {
            if (!this.isMobileMenuOpen) return;

            const focusableElements = this.mainNav.querySelectorAll('a[href], button');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }

    // Public method to update active page
    updateActivePage(pageName) {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(pageName)) {
                link.classList.add('active');
            }
        });
    }
}

// Initialize header navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HeaderNavigation();
});

// Export for use in other modules (if using modules)
// export default HeaderNavigation;


class StructurePageHeader {
    constructor() {
        this.header = document.querySelector('.structure-header-section');
        this.stats = document.querySelectorAll('.stat-number');
        this.navTabs = document.querySelectorAll('.nav-tab');
        this.scrollIndicator = document.querySelector('.scroll-indicator');
        this.backgroundImage = document.querySelector('.background-image');
        
        this.isStatsAnimated = false;
        this.scrollThreshold = 100;
        this.activeTab = 'overview';
        
        this.init();
    }

    init() {
        // Start stats animation when header is in view
        this.setupIntersectionObserver();
        
        // Set up navigation tabs
        this.setupNavigationTabs();
        
        // Set up scroll indicator behavior
        this.setupScrollIndicator();
        
        // Set up background parallax effect
        this.setupParallaxEffect();
        
        // Set up button click handlers
        this.setupButtonHandlers();
        
        // Start floating shapes animation
        this.animateFloatingShapes();
    }

    setupIntersectionObserver() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.5
        };

        const headerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.isStatsAnimated) {
                    this.animateStats();
                    this.isStatsAnimated = true;
                }
            });
        }, observerOptions);

        if (this.header) {
            headerObserver.observe(this.header);
        }
    }

    animateStats() {
        this.stats.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            this.animateCounter(stat, target);
        });
    }

    animateCounter(element, target) {
        const duration = 2000;
        const frameRate = 1000 / 60;
        const totalFrames = Math.round(duration / frameRate);
        const easeOutQuart = (t) => 1 - (--t) * t * t * t;
        
        let frame = 0;
        
        const counter = setInterval(() => {
            frame++;
            const progress = easeOutQuart(frame / totalFrames);
            const currentValue = Math.round(target * progress);
            
            element.textContent = currentValue;
            
            if (frame === totalFrames) {
                clearInterval(counter);
                element.textContent = target;
            }
        }, frameRate);
    }

    setupNavigationTabs() {
        this.navTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const target = tab.getAttribute('data-target');
                this.setActiveTab(tab, target);
            });

            // Keyboard navigation
            tab.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const target = tab.getAttribute('data-target');
                    this.setActiveTab(tab, target);
                }
            });
        });
    }

    setActiveTab(activeTab, target) {
        // Remove active class from all tabs
        this.navTabs.forEach(tab => {
            tab.classList.remove('active');
        });

        // Add active class to clicked tab
        activeTab.classList.add('active');
        this.activeTab = target;

        // Scroll to corresponding section
        this.scrollToSection(target);

        // Track analytics
        this.trackTabClick(target);
    }

    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupScrollIndicator() {
        window.addEventListener('scroll', () => {
            this.handleScrollBehavior();
        });
        
        // Add click handler to scroll indicator
        if (this.scrollIndicator) {
            this.scrollIndicator.addEventListener('click', () => {
                this.scrollToNextSection();
            });
        }
    }

    handleScrollBehavior() {
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        // Hide scroll indicator when user starts scrolling
        if (scrollY > this.scrollThreshold && this.scrollIndicator) {
            this.scrollIndicator.style.opacity = '0';
            this.scrollIndicator.style.pointerEvents = 'none';
        } else if (this.scrollIndicator) {
            this.scrollIndicator.style.opacity = '1';
            this.scrollIndicator.style.pointerEvents = 'auto';
        }
    }

    scrollToNextSection() {
        const nextSection = document.getElementById('organizational-overview');
        if (nextSection) {
            nextSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupParallaxEffect() {
        if (!this.backgroundImage) return;
        
        window.addEventListener('scroll', () => {
            this.updateParallax();
        });
    }

    updateParallax() {
        const scrolled = window.pageYOffset;
        const parallaxSpeed = 0.5;
        const transformValue = scrolled * parallaxSpeed;
        
        if (this.backgroundImage) {
            this.backgroundImage.style.transform = `scale(1.05) translateY(${transformValue}px)`;
        }
    }

    setupButtonHandlers() {
        const primaryButton = document.querySelector('.primary-action');
        const secondaryButton = document.querySelector('.secondary-action');
        
        if (primaryButton) {
            primaryButton.addEventListener('click', (e) => {
                this.trackButtonClick('view_org_chart');
            });
        }
        
        if (secondaryButton) {
            secondaryButton.addEventListener('click', (e) => {
                this.trackButtonClick('contact_administration');
            });
        }
    }

    trackTabClick(tabName) {
        console.log(`Navigation tab clicked: ${tabName}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'tab_click', {
                'event_category': 'structure_header',
                'event_label': tabName
            });
        }
    }

    trackButtonClick(buttonType) {
        console.log(`Header button clicked: ${buttonType}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'button_click', {
                'event_category': 'structure_header',
                'event_label': buttonType
            });
        }
    }

    animateFloatingShapes() {
        const shapes = document.querySelectorAll('.floating-shape');
        
        shapes.forEach((shape, index) => {
            // Randomize initial positions and animations
            const randomX = Math.random() * 80 + 10; // 10% to 90%
            const randomY = Math.random() * 80 + 10;
            const randomSize = Math.random() * 30 + 20; // 20px to 50px
            const randomDuration = Math.random() * 4 + 4; // 4s to 8s
            const randomDelay = Math.random() * 2;
            
            shape.style.left = `${randomX}%`;
            shape.style.top = `${randomY}%`;
            shape.style.width = `${randomSize}px`;
            shape.style.height = `${randomSize}px`;
            shape.style.animationDuration = `${randomDuration}s`;
            shape.style.animationDelay = `${randomDelay}s`;
        });
    }

    // Public method to update header content
    updateHeaderContent(newContent) {
        if (newContent.title) {
            const titleElement = document.querySelector('.page-main-title');
            if (titleElement) {
                titleElement.textContent = newContent.title;
            }
        }
        
        if (newContent.intro) {
            const introElement = document.querySelector('.page-intro-text');
            if (introElement) {
                introElement.textContent = newContent.intro;
            }
        }
        
        if (newContent.stats) {
            this.updateStats(newContent.stats);
        }
    }

    updateStats(newStats) {
        this.stats.forEach((stat, index) => {
            if (newStats[index]) {
                const target = parseInt(newStats[index]);
                stat.setAttribute('data-count', target);
                stat.textContent = '0';
                
                // Re-animate if stats were already animated
                if (this.isStatsAnimated) {
                    this.animateCounter(stat, target);
                }
            }
        });
    }

    // Public method to add new navigation tab
    addNavigationTab(tabData) {
        const navContainer = document.querySelector('.nav-tabs');
        const newTab = document.createElement('button');
        newTab.className = 'nav-tab';
        newTab.setAttribute('data-target', tabData.target);
        newTab.innerHTML = `
            <span class="tab-icon">${tabData.icon}</span>
            ${tabData.label}
        `;
        
        newTab.addEventListener('click', () => {
            this.setActiveTab(newTab, tabData.target);
        });
        
        navContainer.appendChild(newTab);
        this.navTabs = document.querySelectorAll('.nav-tab');
    }

    // Public method to update active tab programmatically
    setActiveTabByName(tabName) {
        const targetTab = Array.from(this.navTabs).find(tab => 
            tab.getAttribute('data-target') === tabName
        );
        
        if (targetTab) {
            this.setActiveTab(targetTab, tabName);
        }
    }

    // Public method to change background image
    changeBackgroundImage(newImageUrl) {
        if (this.backgroundImage) {
            // Create a new image to preload
            const newImage = new Image();
            newImage.src = newImageUrl;
            
            newImage.onload = () => {
                // Add fade transition
                this.backgroundImage.style.opacity = '0';
                
                setTimeout(() => {
                    this.backgroundImage.src = newImageUrl;
                    this.backgroundImage.style.opacity = '1';
                }, 300);
            };
        }
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScrollBehavior());
        window.removeEventListener('scroll', () => this.updateParallax());
        
        this.navTabs.forEach(tab => {
            tab.removeEventListener('click', () => this.setActiveTab);
        });
        
        if (this.scrollIndicator) {
            this.scrollIndicator.removeEventListener('click', () => this.scrollToNextSection());
        }
    }
}

// Global function for button onclick
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Initialize the structure page header when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const structureHeader = new StructurePageHeader();
    
    // Make globally available for debugging and external control
    window.structureHeader = structureHeader;
});

// Export for use in modules
// export default StructurePageHeader;

// Organizational Overview Section Interactivity
document.addEventListener('DOMContentLoaded', function() {
    initializeOrgOverview();
});

function initializeOrgOverview() {
    // Principle cards hover effects
    const principleCards = document.querySelectorAll('.principle-card');
    
    principleCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const principle = this.getAttribute('data-principle');
            highlightRelatedElements(principle);
        });
        
        card.addEventListener('mouseleave', function() {
            resetHighlights();
        });
        
        // Click effect for mobile devices
        card.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                const principle = this.getAttribute('data-principle');
                togglePrincipleFocus(principle, this);
            }
        });
    });
    
    // Organizational chart node interactions
    const chartNodes = document.querySelectorAll('.chart-node');
    
    chartNodes.forEach(node => {
        node.addEventListener('click', function() {
            const level = getNodeLevel(this);
            animateChartFocus(level);
        });
    });
    
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                animateOrgChart();
            }
        });
    }, observerOptions);
    
    const orgSection = document.querySelector('.org-overview');
    if (orgSection) {
        observer.observe(orgSection);
    }
}

function highlightRelatedElements(principle) {
    const allCards = document.querySelectorAll('.principle-card');
    
    allCards.forEach(card => {
        if (card.getAttribute('data-principle') !== principle) {
            card.style.opacity = '0.6';
            card.style.transform = 'scale(0.95)';
        } else {
            card.style.opacity = '1';
            card.style.transform = 'scale(1.05)';
        }
    });
}

function resetHighlights() {
    const allCards = document.querySelectorAll('.principle-card');
    
    allCards.forEach(card => {
        card.style.opacity = '1';
        card.style.transform = 'scale(1)';
    });
}

function togglePrincipleFocus(principle, clickedCard) {
    const allCards = document.querySelectorAll('.principle-card');
    const isCurrentlyFocused = clickedCard.classList.contains('focused');
    
    // Reset all cards
    allCards.forEach(card => {
        card.classList.remove('focused');
        card.style.opacity = '1';
        card.style.transform = 'scale(1)';
    });
    
    // If not currently focused, focus the clicked card
    if (!isCurrentlyFocused) {
        allCards.forEach(card => {
            if (card.getAttribute('data-principle') !== principle) {
                card.style.opacity = '0.6';
                card.style.transform = 'scale(0.95)';
            }
        });
        clickedCard.classList.add('focused');
        clickedCard.style.opacity = '1';
        clickedCard.style.transform = 'scale(1.05)';
    }
}

function getNodeLevel(node) {
    const parentLevel = node.closest('.chart-level');
    if (parentLevel.classList.contains('top-level')) return 'strategic';
    if (parentLevel.classList.contains('executive-level')) return 'executive';
    if (parentLevel.classList.contains('management-level')) return 'management';
    if (parentLevel.classList.contains('department-level')) return 'department';
    return '';
}

function animateChartFocus(level) {
    const allNodes = document.querySelectorAll('.chart-node');
    const connectors = document.querySelectorAll('.chart-connector');
    
    // Reset all elements
    allNodes.forEach(node => {
        node.style.opacity = '0.6';
        node.style.transform = 'scale(0.9)';
    });
    connectors.forEach(connector => {
        connector.style.opacity = '0.3';
    });
    
    // Highlight based on level
    switch(level) {
        case 'strategic':
            highlightLevel('top-level');
            break;
        case 'executive':
            highlightLevel('executive-level');
            highlightConnectors(0); // First connector
            break;
        case 'management':
            highlightLevel('management-level');
            highlightConnectors(0, 1); // First two connectors
            break;
        case 'department':
            highlightLevel('department-level');
            highlightConnectors(0, 1, 2); // All connectors
            break;
    }
    
    // Reset after 3 seconds
    setTimeout(() => {
        allNodes.forEach(node => {
            node.style.opacity = '1';
            node.style.transform = 'scale(1)';
        });
        connectors.forEach(connector => {
            connector.style.opacity = '1';
        });
    }, 3000);
}

function highlightLevel(levelClass) {
    const levelNodes = document.querySelectorAll(`.${levelClass} .chart-node`);
    levelNodes.forEach(node => {
        node.style.opacity = '1';
        node.style.transform = 'scale(1.1)';
        node.style.boxShadow = '0 8px 25px rgba(0,0,0,0.2)';
    });
}

function highlightConnectors(...indices) {
    const connectors = document.querySelectorAll('.chart-connector');
    indices.forEach(index => {
        if (connectors[index]) {
            connectors[index].style.opacity = '1';
            connectors[index].style.transform = 'scale(1.1)';
        }
    });
}

function animateOrgChart() {
    const chartLevels = document.querySelectorAll('.chart-level');
    const connectors = document.querySelectorAll('.chart-connector');
    
    // Animate levels with staggered delay
    chartLevels.forEach((level, index) => {
        setTimeout(() => {
            level.style.opacity = '1';
            level.style.transform = 'translateY(0)';
        }, index * 300);
    });
    
    // Animate connectors
    connectors.forEach((connector, index) => {
        setTimeout(() => {
            connector.style.opacity = '1';
            connector.style.transform = 'scaleY(1)';
        }, (chartLevels.length * 300) + (index * 200));
    });
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    .org-overview .chart-level,
    .org-overview .chart-connector {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.6s ease;
    }
    
    .org-overview .chart-connector {
        transform: scaleY(0);
    }
    
    .org-overview .chart-level.animate-in,
    .org-overview .chart-connector.animate-in {
        opacity: 1;
        transform: translateY(0) scaleY(1);
    }
    
    .principle-card {
        transition: all 0.3s ease;
    }
    
    @media (max-width: 768px) {
        .principle-card.focused {
            z-index: 10;
            position: relative;
        }
    }
`;
document.head.appendChild(style);


// Leadership Hierarchy Manager with Unique Class Names
class SchoolLeadershipHierarchy {
    constructor() {
        this.currentZoomLevel = 1;
        this.maximumZoom = 1.5;
        this.minimumZoom = 0.7;
        this.zoomIncrement = 0.1;
        this.currentActiveNode = null;
        
        this.initializeLeadershipHierarchy();
    }
    
    initializeLeadershipHierarchy() {
        this.setupHierarchyEventListeners();
        this.prepareNodeInformationData();
        this.initializeHierarchyAnimations();
    }
    
    setupHierarchyEventListeners() {
        // Chart view controls
        const viewModeSelector = document.getElementById('hierarchyViewMode');
        const zoomInButton = document.getElementById('hierarchyZoomIn');
        const zoomOutButton = document.getElementById('hierarchyZoomOut');
        const resetViewButton = document.getElementById('hierarchyReset');
        const closePanelButton = document.getElementById('closeInfoPanel');
        
        viewModeSelector.addEventListener('change', (e) => this.applyViewFilter(e.target.value));
        zoomInButton.addEventListener('click', () => this.adjustChartZoom('in'));
        zoomOutButton.addEventListener('click', () => this.adjustChartZoom('out'));
        resetViewButton.addEventListener('click', () => this.restoreDefaultView());
        closePanelButton.addEventListener('click', () => this.hideInformationPanel());
        
        // Node interactions
        const organizationNodes = document.querySelectorAll('.organization-node');
        organizationNodes.forEach(node => {
            node.addEventListener('click', (e) => {
                e.stopPropagation();
                this.processNodeSelection(node);
            });
            
            node.addEventListener('mouseenter', () => this.highlightNodeRelationships(node));
            node.addEventListener('mouseleave', () => this.clearAllHighlights());
        });
        
        // Close info panel when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.organization-node') && !e.target.closest('.hierarchy-info-panel')) {
                this.hideInformationPanel();
            }
        });
    }
    
    prepareNodeInformationData() {
        this.nodeInformationDatabase = {
            'board-directors-info': {
                title: 'Board of Directors',
                content: `
                    <div class="info-details-container">
                        <div class="info-detail-section">
                            <h4>Responsibilities</h4>
                            <ul>
                                <li>Strategic planning and policy development</li>
                                <li>Financial oversight and budgeting</li>
                                <li>Governance and compliance monitoring</li>
                                <li>Community representation and engagement</li>
                            </ul>
                        </div>
                        <div class="info-detail-section">
                            <h4>Composition</h4>
                            <p>5 members including Chairperson, Vice Chairperson, Secretary, Treasurer, and Community Representative</p>
                        </div>
                        <div class="info-detail-section">
                            <h4>Meetings</h4>
                            <p>Monthly board meetings with quarterly review sessions</p>
                        </div>
                    </div>
                `
            },
            'principal-leader-info': {
                title: 'School Principal - Dr. Sarah Johnson',
                content: `
                    <div class="info-details-container">
                        <div class="info-detail-section">
                            <h4>Role Overview</h4>
                            <p>As the chief executive officer of the school, the Principal provides overall leadership and strategic direction.</p>
                        </div>
                        <div class="info-detail-section">
                            <h4>Key Responsibilities</h4>
                            <ul>
                                <li>Overall school administration and management</li>
                                <li>Implementation of educational policies</li>
                                <li>Staff recruitment and development</li>
                                <li>Budget management and resource allocation</li>
                                <li>Community and parent relations</li>
                            </ul>
                        </div>
                        <div class="info-detail-section">
                            <h4>Qualifications</h4>
                            <p>PhD in Educational Leadership, 15+ years in education</p>
                        </div>
                    </div>
                `
            },
            'vice-principal-info': {
                title: 'Vice Principals',
                content: `
                    <div class="info-details-container">
                        <div class="info-detail-section">
                            <h4>Positions</h4>
                            <ul>
                                <li><strong>Vice Principal (Academic):</strong> Curriculum development and teaching standards</li>
                                <li><strong>Vice Principal (Operations):</strong> Day-to-day school management</li>
                                <li><strong>Vice Principal (Student Affairs):</strong> Student welfare and discipline</li>
                            </ul>
                        </div>
                    </div>
                `
            },
            'academic-dean-info': {
                title: 'Academic Dean',
                content: `
                    <div class="info-details-container">
                        <div class="info-detail-section">
                            <h4>Primary Focus</h4>
                            <p>Oversees all academic programs and ensures educational excellence across all departments.</p>
                        </div>
                    </div>
                `
            },
            'math-department-info': {
                title: 'Mathematics Department',
                content: `<p>Led by Dr. Robert Chen, our Mathematics Department focuses on developing critical thinking and problem-solving skills.</p>`
            }
        };
    }
    
    processNodeSelection(selectedNode) {
        const nodeInfoKey = selectedNode.getAttribute('data-node-info');
        
        // Remove active class from all nodes
        document.querySelectorAll('.organization-node').forEach(node => node.classList.remove('node-active'));
        
        // Add active class to clicked node
        selectedNode.classList.add('node-active');
        this.currentActiveNode = selectedNode;
        
        // Display information panel
        this.displayNodeInformation(nodeInfoKey);
        
        // Highlight hierarchy path
        this.visualizeHierarchyPath(selectedNode);
    }
    
    displayNodeInformation(infoKey) {
        const infoPanel = document.getElementById('hierarchyDetailPanel');
        const panelTitle = document.getElementById('infoPanelTitle');
        const panelContent = document.getElementById('infoPanelContent');
        
        if (this.nodeInformationDatabase[infoKey]) {
            panelTitle.textContent = this.nodeInformationDatabase[infoKey].title;
            panelContent.innerHTML = this.nodeInformationDatabase[infoKey].content;
            infoPanel.classList.add('panel-active');
        }
    }
    
    hideInformationPanel() {
        const infoPanel = document.getElementById('hierarchyDetailPanel');
        infoPanel.classList.remove('panel-active');
        
        // Remove active class from all nodes
        document.querySelectorAll('.organization-node').forEach(node => node.classList.remove('node-active'));
        this.currentActiveNode = null;
        
        // Clear highlights
        this.clearAllHighlights();
    }
    
    visualizeHierarchyPath(selectedNode) {
        this.clearAllHighlights();
        
        const nodeLevelValue = this.calculateNodeLevel(selectedNode);
        const allHierarchyLevels = document.querySelectorAll('.hierarchy-level');
        
        // Highlight levels up to and including the selected node's level
        allHierarchyLevels.forEach(level => {
            const levelNumber = parseInt(level.className.match(/level-(\d)/)[1]);
            if (levelNumber <= nodeLevelValue) {
                level.style.opacity = '1';
            } else {
                level.style.opacity = '0.3';
            }
        });
    }
    
    highlightNodeRelationships(hoveredNode) {
        if (this.currentActiveNode) return; // Don't highlight during active selection
        
        const hoveredNodeLevel = this.calculateNodeLevel(hoveredNode);
        const allOrganizationNodes = document.querySelectorAll('.organization-node');
        
        allOrganizationNodes.forEach(otherNode => {
            const otherNodeLevel = this.calculateNodeLevel(otherNode);
            if (otherNodeLevel === hoveredNodeLevel) {
                otherNode.style.transform = 'scale(1.05)';
                otherNode.style.boxShadow = '0 6px 20px rgba(0,0,0,0.15)';
            }
        });
    }
    
    clearAllHighlights() {
        if (this.currentActiveNode) return; // Keep highlights during active selection
        
        const allHierarchyLevels = document.querySelectorAll('.hierarchy-level');
        const allOrganizationNodes = document.querySelectorAll('.organization-node');
        
        allHierarchyLevels.forEach(level => {
            level.style.opacity = '1';
        });
        
        allOrganizationNodes.forEach(node => {
            node.style.transform = '';
            node.style.boxShadow = '';
        });
    }
    
    calculateNodeLevel(nodeElement) {
        const levelContainer = nodeElement.closest('.hierarchy-level');
        const levelMatch = levelContainer.className.match(/level-(\d)/);
        return levelMatch ? parseInt(levelMatch[1]) : 0;
    }
    
    applyViewFilter(viewType) {
        const allHierarchyLevels = document.querySelectorAll('.hierarchy-level');
        
        allHierarchyLevels.forEach(level => {
            const levelCategory = level.getAttribute('data-hierarchy-level');
            
            switch(viewType) {
                case 'strategic':
                    level.style.display = ['strategic', 'executive'].includes(levelCategory) ? 'block' : 'none';
                    break;
                case 'operational':
                    level.style.display = ['department', 'faculty', 'support'].includes(levelCategory) ? 'block' : 'none';
                    break;
                default:
                    level.style.display = 'block';
            }
        });
        
        // Reset zoom when changing view
        this.restoreDefaultView();
    }
    
    adjustChartZoom(direction) {
        const hierarchyChart = document.getElementById('orgHierarchyChart');
        
        if (direction === 'in' && this.currentZoomLevel < this.maximumZoom) {
            this.currentZoomLevel += this.zoomIncrement;
        } else if (direction === 'out' && this.currentZoomLevel > this.minimumZoom) {
            this.currentZoomLevel -= this.zoomIncrement;
        }
        
        hierarchyChart.style.transform = `scale(${this.currentZoomLevel})`;
        hierarchyChart.style.transformOrigin = 'center top';
    }
    
    restoreDefaultView() {
        const hierarchyChart = document.getElementById('orgHierarchyChart');
        this.currentZoomLevel = 1;
        hierarchyChart.style.transform = 'scale(1)';
        
        // Reset view to full hierarchy
        document.getElementById('hierarchyViewMode').value = 'full';
        this.applyViewFilter('full');
        this.hideInformationPanel();
    }
    
    initializeHierarchyAnimations() {
        // Animate chart on load
        setTimeout(() => {
            this.animateChartEntranceSequence();
        }, 500);
    }
    
    animateChartEntranceSequence() {
        const hierarchyLevels = document.querySelectorAll('.hierarchy-level');
        const levelConnectors = document.querySelectorAll('.hierarchy-connector');
        
        hierarchyLevels.forEach((level, index) => {
            level.style.opacity = '0';
            level.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                level.style.transition = 'all 0.6s ease';
                level.style.opacity = '1';
                level.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        levelConnectors.forEach((connector, index) => {
            connector.style.opacity = '0';
            
            setTimeout(() => {
                connector.style.transition = 'all 0.4s ease';
                connector.style.opacity = '1';
            }, (hierarchyLevels.length * 200) + (index * 100));
        });
    }
}

// Initialize the leadership hierarchy when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    new SchoolLeadershipHierarchy();
});

// Add touch support for mobile devices
document.addEventListener('touchstart', function() {}, { passive: true });

class SiteFooter {
    constructor() {
        this.footer = document.querySelector('.site-footer');
        this.backToTopBtn = document.getElementById('backToTop');
        this.currentYearElement = document.getElementById('currentYear');
        this.newsletterForm = document.querySelector('.newsletter-form');
        
        this.scrollThreshold = 300;
        this.isScrolling = false;
        
        this.initialize();
    }

    initialize() {
        // Set current year in copyright
        this.setCurrentYear();
        
        // Set up back to top button
        this.setupBackToTop();
        
        // Set up newsletter form
        this.setupNewsletterForm();
        
        // Set up smooth scrolling for internal links
        this.setupSmoothScrolling();
        
        // Set up intersection observer for animations
        this.setupAnimations();
    }

    setCurrentYear() {
        if (this.currentYearElement) {
            const currentYear = new Date().getFullYear();
            this.currentYearElement.textContent = currentYear;
        }
    }

    setupBackToTop() {
        if (!this.backToTopBtn) return;
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Scroll to top when clicked
        this.backToTopBtn.addEventListener('click', () => {
            this.scrollToTop();
        });
        
        // Keyboard navigation
        this.backToTopBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.scrollToTop();
            }
        });
    }

    handleScroll() {
        if (this.isScrolling) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > this.scrollThreshold) {
            this.backToTopBtn.classList.add('visible');
        } else {
            this.backToTopBtn.classList.remove('visible');
        }
    }

    scrollToTop() {
        this.isScrolling = true;
        
        // Add smooth scroll behavior
        const scrollOptions = {
            top: 0,
            behavior: 'smooth'
        };
        
        window.scrollTo(scrollOptions);
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 1000);
    }

    setupNewsletterForm() {
        if (!this.newsletterForm) return;
        
        this.newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSubmit();
        });
        
        // Add input validation
        const emailInput = this.newsletterForm.querySelector('.email-input');
        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validateEmailInput(emailInput);
            });
        }
    }

    validateEmailInput(input) {
        const email = input.value.trim();
        const isValid = this.isValidEmail(email);
        
        if (email === '') {
            input.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        } else if (isValid) {
            input.style.borderColor = '#2ecc71';
        } else {
            input.style.borderColor = '#e74c3c';
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    handleNewsletterSubmit() {
        const emailInput = this.newsletterForm.querySelector('.email-input');
        const submitBtn = this.newsletterForm.querySelector('.subscribe-btn');
        const email = emailInput.value.trim();
        
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            this.subscribeToNewsletter(email);
            
            // Reset form
            emailInput.value = '';
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            emailInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        }, 1500);
    }

    subscribeToNewsletter(email) {
        // In a real implementation, this would be an API call
        console.log(`Subscribing email: ${email}`);
        
        // Show success message
        this.showMessage('Thank you for subscribing to our newsletter!', 'success');
        
        // Track newsletter signup
        this.trackNewsletterSignup(email);
    }

    showMessage(message, type) {
        // Remove existing messages
        const existingMessage = this.newsletterForm.querySelector('.form-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create new message
        const messageElement = document.createElement('div');
        messageElement.className = `form-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            padding: 0.75rem;
            margin-top: 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.9rem;
            text-align: center;
            background: ${type === 'success' ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)'};
            border: 1px solid ${type === 'success' ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)'};
            color: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        `;
        
        this.newsletterForm.appendChild(messageElement);
        
        // Auto-remove message after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }

    setupSmoothScrolling() {
        // Add smooth scrolling for internal footer links
        const footerLinks = this.footer.querySelectorAll('a[href^="#"]');
        footerLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                if (href !== '#') {
                    e.preventDefault();
                    this.scrollToElement(href);
                }
            });
        });
    }

    scrollToElement(selector) {
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupAnimations() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const footerObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFooterSections();
                }
            });
        }, observerOptions);

        if (this.footer) {
            footerObserver.observe(this.footer);
        }
    }

    animateFooterSections() {
        const sections = this.footer.querySelectorAll('.footer-section');
        
        sections.forEach((section, index) => {
            setTimeout(() => {
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
        
        // Add initial styles for animation
        sections.forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    }

    trackNewsletterSignup(email) {
        // Analytics tracking
        console.log(`Newsletter signup: ${email}`);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', 'newsletter_signup', {
                'event_category': 'footer',
                'event_label': 'newsletter_subscription'
            });
        }
    }

    // Public method to update contact information
    updateContactInfo(newInfo) {
        if (newInfo.address) {
            const addressElement = this.footer.querySelector('.contact-value');
            if (addressElement) {
                addressElement.textContent = newInfo.address;
            }
        }
        
        if (newInfo.phone) {
            const phoneLink = this.footer.querySelector('a[href^="tel:"]');
            if (phoneLink) {
                phoneLink.textContent = newInfo.phone;
                phoneLink.setAttribute('href', `tel:${newInfo.phone.replace(/\D/g, '')}`);
            }
        }
        
        if (newInfo.email) {
            const emailLink = this.footer.querySelector('a[href^="mailto:"]');
            if (emailLink) {
                emailLink.textContent = newInfo.email;
                emailLink.setAttribute('href', `mailto:${newInfo.email}`);
            }
        }
    }

    // Public method to add social media link
    addSocialMediaLink(platform, url, label) {
        const socialLinksContainer = this.footer.querySelector('.social-links');
        if (!socialLinksContainer) return;
        
        const socialLink = document.createElement('a');
        socialLink.className = `social-link ${platform.toLowerCase()}`;
        socialLink.href = url;
        socialLink.setAttribute('aria-label', label);
        socialLink.target = '_blank';
        socialLink.rel = 'noopener noreferrer';
        
        // Add platform-specific SVG icon
        const iconSvg = this.getSocialIcon(platform);
        socialLink.innerHTML = `${iconSvg}<span class="social-name">${platform}</span>`;
        
        socialLinksContainer.appendChild(socialLink);
    }

    getSocialIcon(platform) {
        const icons = {
            'Facebook': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z"/></svg>',
            'Twitter': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z"/></svg>',
            'Instagram': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'YouTube': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'LinkedIn': '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
        };
        
        return icons[platform] || icons['Twitter'];
    }

    // Clean up method
    destroy() {
        window.removeEventListener('scroll', () => this.handleScroll());
        
        if (this.backToTopBtn) {
            this.backToTopBtn.removeEventListener('click', () => this.scrollToTop());
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.removeEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
}

// Initialize the footer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const siteFooter = new SiteFooter();
    
    // Make globally available
    window.siteFooter = siteFooter;
});

// Export for use in modules
// export default SiteFooter;